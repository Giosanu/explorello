import React from "react";
import { View, Text, FlatList, Image } from "react-native";
import {
  Input,
  Button,
  ListItem,
  Rating,
  AirbnbRating
} from "react-native-elements";
import { NavigationEvents } from "react-navigation";
import { navigationOptions } from "../../constants/headerStyles";
import Icon from "react-native-vector-icons/MaterialCommunityIcons";
import AwesomeIcon from "react-native-vector-icons/FontAwesome5";
import {
  primaryBlue,
  stridentRed,
  stridentYellow,
  primaryRed
} from "../../constants/Colors";
import { GoogleApiKey } from "../../config/keys";
import { connect } from "react-redux";
import LoadingScreen from "../LoadingScreen";
import { fetchEvents, fetchEvent } from "../routes/RoutesActions";

class EventsScreen extends React.Component {
  static navigationOptions = {
    ...navigationOptions,
    ...{
      headerLeft: props => {
        return (
          <Button
            containerStyle={{ backgroundColor: "transparent" }}
            buttonStyle={{ backgroundColor: "transparent" }}
            title=""
            onPress={props.onPress}
            icon={
              <Icon name="arrow-left" style={{ color: "#fff", fontSize: 24 }} />
            }
          />
        );
      },
      headerRight: <View />
    }
  };
  fetchEvents = (filter = null) => {
    this.props.fetchEvents(
      this.props.navigation.state.params,
      filter
    );
  };
  componentDidMount() {
    //item.name || item.url || item.images[0].url || item.dates.start.localDate || item.promoter.name || item._embedded.venues[0].name
  }
  state = {
    filter: null
  };
  render() {
    const { filter } = this.state
    const { events, loading } = this.props;
    return (
      <View style={{ flex: 1, backgroundColor: primaryBlue }}>
        <View
          style={{
            width: "100%",
            justifyContent: "space-around",
            alignItems: "center",
            flexDirection: 'row',
            display: "flex",
            borderBottomColor: '#fff',
            borderBottomWidth: 1,
            marginTop: 10,
            paddingBottom: 10
          }}
        >
          <Button
            title="Sports"
            buttonStyle={{backgroundColor: 'transparent'}}
            titleStyle={{color: filter === 'Sports' ? stridentYellow  : '#eee', fontSize: 16, fontFamily: 'Montserrat-SemiBold'}}
            containerStyle={{ display:'flex', alignItems: 'center', width: 80, borderRadius: 15, backgroundColor: 'transparent'}}
            icon={<AwesomeIcon name="volleyball-ball" style={{paddingLeft: 5, fontSize: 16, marginRight: 5,color: filter === 'Sports' ? stridentYellow  : '#eee'}} />}
            onPress={() =>
              this.setState({ filter: "Sports" }, () => this.fetchEvents("Sports"))
            }
          />
          <Button
            title="Music"
            buttonStyle={{backgroundColor: 'transparent'}}
            titleStyle={{color: filter === 'Music' ? stridentYellow  : '#eee', fontSize: 16, fontFamily: 'Montserrat-SemiBold'}}
            containerStyle={{ display:'flex', alignItems: 'center', width: 80, borderRadius: 15, backgroundColor: 'transparent'}}
            icon={<AwesomeIcon name="guitar" style={{paddingLeft: 5, fontSize: 16, marginRight: 5,color: filter === 'Music' ? stridentYellow  : '#eee'}} />}
            onPress={() => this.setState({ filter: "Music" }, () => this.fetchEvents("Music"))}
          />
          <Button
            title="Food"
            buttonStyle={{backgroundColor: 'transparent'}}
            titleStyle={{color: filter === 'Food' ? stridentYellow  : '#eee', fontSize: 16, fontFamily: 'Montserrat-SemiBold'}}
            containerStyle={{ display:'flex', alignItems: 'center', width: 80, borderRadius: 15, backgroundColor: 'transparent'}}
            icon={<AwesomeIcon name="hamburger" style={{paddingLeft: 5, fontSize: 16, marginRight: 5,color: filter === 'Food' ? stridentYellow  : '#eee'}} />}
            onPress={() => this.setState({ filter: "Food" }, () => this.fetchEvents("Food"))}
          />
          <Button
            title="Hot"
            buttonStyle={{backgroundColor: 'transparent'}}
            titleStyle={{color: filter ? '#eee' : stridentYellow  , fontSize: 16, fontFamily: 'Montserrat-SemiBold'}}
            containerStyle={{ display:'flex', alignItems: 'center', width: 80, borderRadius: 15, backgroundColor: 'transparent'}}
            icon={<AwesomeIcon name="chart-line" style={{paddingLeft: 5, fontSize: 18, marginRight: 5,color: filter ? '#eee' : stridentYellow }} />}
            onPress={() => this.setState({ filter: null }, () => this.fetchEvents())}
          />
        </View>
        {!loading ? (
          <FlatList
            keyExtractor={(item, index) => index.toString()}
            data={events}
            renderItem={({ item }) => (
              <ListItem
                title={item.name}
                containerStyle={{
                  backgroundColor: "transparent",
                  borderBottomColor: "#fff",
                  borderBottomWidth: 1
                }}
                rightContentContainerStyle={{
                  display: "flex",
                  height: "100%",
                  borderLeftColor: "#eee",
                  paddingTop: 3,
                  borderLeftWidth: 1,
                  paddingLeft: 10,
                  justifyContent: "flex-start"
                }}
                titleStyle={{
                  fontFamily: "Montserrat-Light",
                  fontSize: 20,
                  color: "#fff",
                  marginBottom: 10
                }}
                rightTitle={
                  <View
                    style={{
                      marginBottom: 10,
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center"
                    }}
                  >
                    <Image
                      style={{ width: 75, height: 75, borderRadius: 50 }}
                      source={{ uri: item.images[0].url }}
                    />
                    <View
                      style={{
                        marginTop: 15,
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "center"
                      }}
                    >
                      <Button
                        title="See event"
                        titleStyle={{
                          fontFamily: "Montserrat-SemiBold",
                          fontSize: 18,
                          padding: 0,
                          color: stridentRed
                        }}
                        buttonStyle={{
                          backgroundColor: "transparent",
                          padding: 0,
                          paddingTop: 8,
                          paddingBottom: 10
                        }}
                        onPress={() =>
                          this.props.fetchEvent(item.id, this.props.navigation.navigate)
                        }
                        containerStyle={{
                          backgroundColor: "transparent",
                          padding: 0,
                          marginTop: 5,
                          width: "90%",
                          borderTopWidth: 1,
                          borderTopColor: "#fff",
                          marginRight: 8
                        }}
                      />
                    </View>
                  </View>
                }
                subtitle={
                  <View style={{ display: "flex" }}>
                    <View style={{ display: "flex" }}>
                      <View
                        style={{
                          marginBottom: 10,
                          marginTop: 10,
                          display: "flex",
                          flexDirection: "row",
                          justifyContent: "flex-start",
                          alignItems: "center"
                        }}
                      >
                        <AwesomeIcon
                          name="ad"
                          style={{
                            fontSize: 16,
                            paddingRight: 12,
                            color: stridentYellow
                          }}
                        />
                        <Text
                          style={{
                            fontSize: 16,
                            color: "#fff",
                            fontFamily: "Montserrat-SemiBold"
                          }}
                        >
                          {item.promoter && item.promoter.name}
                        </Text>
                      </View>
                      <View
                        style={{
                          marginBottom: 10,
                          display: "flex",
                          flexDirection: "row",
                          alignItems: "center"
                        }}
                      >
                        <AwesomeIcon
                          name="map-marker-alt"
                          style={{
                            fontSize: 14,
                            paddingRight: 14,
                            color: stridentRed
                          }}
                        />
                        <Text
                          style={{
                            fontSize: 16,
                            color: "#fff",
                            fontFamily: "Montserrat-SemiBold"
                          }}
                        >
                          {item._embedded.venues[0].name}
                        </Text>
                      </View>
                    </View>

                    <View
                      style={{
                        marginBottom: 10,
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "center"
                      }}
                    >
                      <AwesomeIcon
                        name="calendar"
                        style={{
                          fontSize: 14,
                          paddingRight: 12,
                          color: "#fff"
                        }}
                      />
                      <Text
                        numberOfLines={2}
                        style={{
                          flex: 1,
                          flexWrap: "wrap",
                          fontSize: 16,
                          color: "#fff",
                          fontFamily: "Montserrat-Regular"
                        }}
                      >
                        {item.dates.start.localDate}
                      </Text>
                    </View>
                  </View>
                }
                key={item.id}
              />
            )}
          />
        ) : (
          <LoadingScreen />
        )}
      </View>
    );
  }
}

export default connect(
  state => ({
    events: state.routes.events,
    loading: state.routes.loading
  }),
  { fetchEvents, fetchEvent }
)(EventsScreen);
