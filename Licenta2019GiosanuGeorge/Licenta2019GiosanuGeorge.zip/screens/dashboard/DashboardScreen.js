import React, { Component } from "react";
import { View, Text, Image, ImageBackground } from "react-native";
import { connect } from "react-redux";
import { Button } from "react-native-elements";
import Geolocation from "react-native-geolocation-service";
import Icon from "react-native-vector-icons/MaterialCommunityIcons";
import { PermissionsAndroid } from "react-native";
import { setCurrentPosition, storeRoute } from '../add-route/AddRouteActions'
import AwesomeIcon from "react-native-vector-icons/FontAwesome5";
import LoadingScreen from "../LoadingScreen";
import {
  primaryBlue,
  primaryRed,
  primaryYellow,
  stridentYellow,
  stridentRed
} from "../../constants/Colors";
import { GoogleApiKey } from "../../config/keys";
import { navigationOptions } from "../../constants/headerStyles";
import firebase from "react-native-firebase";
import { fetchRoutes, changeSearchBy } from "../routes/RoutesActions";

async function requestLocationPermission() {
  try {
    const granted = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
      {
        title: "Cool Photo App Camera Permission",
        message:
          "Cool Photo App needs access to your camera " +
          "so you can take awesome pictures.",
        buttonNeutral: "Ask Me Later",
        buttonNegative: "Cancel",
        buttonPositive: "OK"
      }
    );
    if (granted === PermissionsAndroid.RESULTS.GRANTED) {
      return true;
    } else {
      return false;
    }
  } catch (err) {
    console.warn(err);
  }
}

class DashboardScreen extends Component {
  static navigationOptions = navigationOptions;
  componentWillMount() {
    this.setState({ locationPermission: requestLocationPermission() });
    // this.callMeBaby();
  }
  constructor(props) {
    super(props);
    this.state = {
      locationPermission: false,
      loading: false,
      locationAvailable: true,
      position: {
        latitude: 45.78825,
        longitude: -10.4324,
        latitudeDelta: 0.04,
        longitudeDelta: 0.006
      },
      currentCity: "City",
      currentState: "State",
      location: null,
      formattedAddress: []
    };
  }
  getCurrentPosition = () => {
    this.setState({ loading: true });
    if (this.state.locationPermission) {
      Geolocation.getCurrentPosition(
        position => {
          let pos = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            latitudeDelta: 0.09,
            longitudeDelta: 0.04
          }
          this.setState({
            position: pos
          })
          this.props.setCurrentPosition(pos)
          fetch(
            "https://maps.googleapis.com/maps/api/geocode/json?latlng=" +
              position.coords.latitude +
              "," +
              position.coords.longitude +
              "&key=" +
              GoogleApiKey +
              "&result_type=locality"
          )
            .then(response => response.json())
            .then(responseJson => {
              let currentCity;
              let currentState;
              let formattedAddress;
              let location = {
                lat: position.coords.latitude,
                lng: position.coords.longitude,
                latitudeDelta: 0.09,
                longitudeDelta: 0.04
              };
              let locationAvailable = true;
              if (responseJson.plus_code.compound_code) {
                let result = responseJson.plus_code.compound_code
                  .replace(
                    responseJson.plus_code.compound_code.split(" ")[0] + " ",
                    ""
                  )
                  .split(", ");
                currentCity = result[0];
                currentState = result[result.length - 1];
                if (responseJson.results.length > 0) {
                  if (
                    responseJson.results[0].geometry &&
                    responseJson.results[0].geometry.location
                  ) {
                    location = responseJson.results[0].geometry.location;
                  }
                  formattedAddress = responseJson.results[0].formatted_address
                    .replace(/[0-9]/g, "")
                    .split(",");
                } else {
                  formattedAddress = [currentCity, currentState];
                }
              } else {
                formattedAddress = ["Narnia..", "Sorry, we couldn't find you"];
                locationAvailable = false;
              }
              this.setState({
                currentCity,
                currentState,
                formattedAddress,
                location,
                locationAvailable,
                loading: false
              });
              this.props.storeRoute({
                formattedAddress
              })
            });
        },
        error => {
          // See error code charts below.
          console.log(error.code, error.message);
          this.setState({ loading: false });
        },
        { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
      );
    }
  };
  componentDidMount() {
    this.getCurrentPosition();
  }
  addRoute = () => {
    const { formattedAddress } = this.state;
    this.props.navigation.navigate("AddRouteLanding", {
      ...this.state.location,
      ...{ formattedAddress }
    });
  };
  searchRoute = () => {
    const { navigation, fetchRoutes, searchBy } = this.props;
    changeSearchBy(this.state.currentCity);
    fetchRoutes(this.state.currentCity);
    navigation.navigate("RoutesScreen", true);
  };
  render() {
    const { loading } = this.state;
    return !loading ? (
      <View
        style={{
          flex: 1,
          backgroundColor: primaryBlue,
          paddingTop: 20,
          position: "relative"
        }}
      >
        <Image
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "120%",
            opacity: 0.15
          }}
          source={require("../../assets/images/mozaic.png")}
        />
        <View
          style={{
            width: "100%",
            display: "flex",
            alignItems: "center"
          }}
        >
          <Text
            style={{
              fontSize: 22,
              fontFamily: "Montserrat-SemiBold",
              color: "#eee",
              marginBottom: 20
            }}
          >
            {" "}
            Currently visiting{" "}
          </Text>
          {!this.state.locationAvailable ? (
            <Image
              style={{ height: 90, width: 60, marginBottom: 30 }}
              source={require("../../assets/images/narnia.png")}
            />
          ) : (
            <AwesomeIcon
              style={{ fontSize: 70, color: stridentRed, marginBottom: 30 }}
              name="map-marked"
            />
          )}
          {this.state.formattedAddress.map((fa, index) => (
            <Text
              key={fa}
              style={{
                fontSize: 26 - this.state.formattedAddress.length,
                color: "#fff",
                marginBottom: 5,
                textAlign: "center",
                fontFamily: "Montserrat-Bold",
                maxWidth: "80%"
              }}
            >
              {fa}
            </Text>
          ))}
          <View
            style={{
              display: "flex",
              flexDirection: "column",
              marginTop: 25,
              justifyContent: "space-between",
              alignContent: "center"
            }}
          >
            <View
              style={{
                display: "flex",
                flexDirection: "row",
                justifyContent: "space-between",
                alignContent: "center",
                marginBottom: 30
              }}
            >
              <Button
                buttonStyle={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  backgroundColor: "transparent"
                }}
                title="GPS"
                iconContainerStyle={{ width: "100%" }}
                icon={
                  <Icon
                    style={{ fontSize: 24, color: '#B6174B' }}
                    name="crosshairs-gps"
                  />
                }
                titleStyle={{
                  fontSize: 17,
                  color: primaryBlue,
                  fontFamily: "Montserrat-Bold"
                }}
                onPress={this.getCurrentPosition}
                containerStyle={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  width: "45%",
                  backgroundColor: "#FFF8F0", //"rgba(0,48,73,0.9)",
                  paddingRight: 10,
                  borderRadius: 20,
                  paddingLeft: 10
                }}
              />
              <Button
                buttonStyle={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  backgroundColor: "transparent"
                }}
                title="Add a route"
                iconContainerStyle={{ width: "100%" }}
                icon={
                  <Icon
                    style={{ fontSize: 26, color: '#333' }}
                    name="map-marker-plus"
                  />
                }
                titleStyle={{
                  fontSize: 17,
                  color: primaryBlue,
                  fontFamily: "Montserrat-Bold"
                }}
                onPress={this.addRoute}
                containerStyle={{
                  display: "flex",
                  alignItems: "center",
                  borderRadius: 20,
                  justifyContent: "center",
                  width: "45%",
                  backgroundColor: "#FFF8F0", //"rgba(0,48,73,0.9)",
                  paddingRight: 10,
                  paddingLeft: 10
                }}
              />
            </View>
            <View
              style={{
                display: "flex",
                flexDirection: "row",
                justifyContent: "space-between",
                alignContent: "center"
              }}
            >
              {this.state.locationAvailable && <Button
                buttonStyle={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  backgroundColor: "transparent"
                }}
                title="Concerts and events"
                iconContainerStyle={{ width: "100%" }}
                icon={
                  <AwesomeIcon
                    style={{ fontSize: 24, color: primaryRed }}
                    name="ticket-alt"
                  />
                }
                titleStyle={{
                  fontSize: 17,
                  color: primaryBlue,
                  fontFamily: "Montserrat-Bold"
                }}
                onPress={() => {this.props.navigation.navigate("EventsScreen", this.state.position)}}
                containerStyle={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  width: "45%",
                  backgroundColor: "#FFF8F0", //"rgba(0,48,73,0.9)",
                  paddingRight: 10,
                  borderRadius: 20,
                  paddingLeft: 10
                }}
              />}
              {this.state.locationAvailable && <Button
                buttonStyle={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  backgroundColor: "transparent"
                }}
                title={`${this.state.currentCity}'s routes`}
                iconContainerStyle={{ width: "100%" }}
                icon={
                  <AwesomeIcon
                    style={{ fontSize: 24, color: stridentRed }}
                    name="search-location"
                  />
                }
                titleStyle={{
                  fontSize: 17,
                  color: primaryBlue,
                  fontFamily: "Montserrat-Bold"
                }}
                onPress={() => this.searchRoute()}
                containerStyle={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  width: "45%",
                  backgroundColor: "#FFF8F0", //"rgba(0,48,73,0.9)",
                  paddingRight: 10,
                  borderRadius: 20,
                  paddingLeft: 10
                }}
              />}
            </View>
          </View>
        </View>
      </View>
    ) : (
      <LoadingScreen />
    );
  }
}

export default connect(
  state => ({
    searchBy: state.routes.searchBy
  }),
  { fetchRoutes, changeSearchBy, setCurrentPosition, storeRoute }
)(DashboardScreen);
