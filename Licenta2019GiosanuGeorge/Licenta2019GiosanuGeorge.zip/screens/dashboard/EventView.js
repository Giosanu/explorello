import React from "react";
import { View, Text, Image, ScrollView, TouchableOpacity } from "react-native";
import { Button, ListItem, Input, AirbnbRating } from "react-native-elements";
import { connect } from "react-redux";
import AwesomeIcon from "react-native-vector-icons/FontAwesome5";
import Geolocation from "react-native-geolocation-service";
import { navigationOptions } from "../../constants/headerStyles";
import MapView, { Marker, PROVIDER_GOOGLE } from "react-native-maps";
import MapViewDirections from "react-native-maps-directions";
import Icon from "react-native-vector-icons/MaterialCommunityIcons";
import {
  stridentRed,
  primaryBlue,
  stridentYellow,
  primaryYellow,
  primaryRed
} from "../../constants/Colors";
import { GoogleApiKey } from "../../config/keys";
import { mapStyle } from "../../constants/Styles";
import { fetchEvent, attendEvent } from "../routes/RoutesActions";
import LoadingScreen from "../LoadingScreen";
import { successToast } from "../../constants/Functions";

class EventView extends React.Component {
  static navigationOptions = {
    ...navigationOptions,
    ...{
      headerLeft: props => {
        return (
          <Button
            containerStyle={{ backgroundColor: "transparent" }}
            buttonStyle={{ backgroundColor: "transparent" }}
            title=""
            onPress={props.onPress}
            icon={
              <Icon name="arrow-left" style={{ color: "#fff", fontSize: 24 }} />
            }
          />
        );
      },
      headerRight: <View />
    }
  };
  state = {
    showDetails: false,
    mapLoading: true,
    location: null
  };
  addEvent = () => {
    const { item, attendEvent, currentUser } = this.props;
    attendEvent(currentUser.uid, {
      position: {
        latitude: parseFloat(item._embedded.venues[0].location.latitude),
        longitude: parseFloat(item._embedded.venues[0].location.longitude),
        latitudeDelta: 0.09,
        longitudeDelta: 0.04
      },
      name: item.name,
      description: item._embedded.venues[0].name
    })
  }
  render() {
    const { item } = this.props;
    const { mapLoading, showDetails, location } = this.state;
    return !this.props.loading ? (
      <View style={{ flex: 1, position: "relative" }}>
        <MapView
          provider={PROVIDER_GOOGLE}
          showsMyLocationButton={false}
          onMapReady={() => this.setState({ mapLoading: false })}
          loadingEnabled={true}
          region={
            location || {
              latitude: parseFloat(item._embedded.venues[0].location.latitude),
              longitude: parseFloat(
                item._embedded.venues[0].location.longitude
              ),
              latitudeDelta: 0.09,
              longitudeDelta: 0.04
            }
          }
          loadingIndicatorColor={primaryYellow}
          style={{
            width: "100%",
            height: "100%",
            top: mapLoading ? "-100%" : 0,
            position: "absolute"
          }}
          onRegionChangeComplete={location => this.setState({ location })}
          customMapStyle={mapStyle}
        >
          <Marker
            coordinate={{
              latitude: parseFloat(item._embedded.venues[0].location.latitude),
              longitude: parseFloat(item._embedded.venues[0].location.longitude)
            }}
            title={`${item.name}`}
            description={item._embedded.venues[0].name || ""}
            tracksViewChanges={false}
            pinColor="indigo"
          />
        </MapView>
        <ListItem
          title={item.name}
          containerStyle={{
            backgroundColor: primaryBlue,
            borderBottomColor: "#fff",
            borderBottomWidth: 1
          }}
          rightContentContainerStyle={{
            display: "flex",
            height: "100%",
            borderLeftColor: "#eee",
            paddingTop: 3,
            borderLeftWidth: 1,
            paddingLeft: 10,
            justifyContent: "flex-start"
          }}
          titleStyle={{
            fontFamily: "Montserrat-Light",
            fontSize: 20,
            color: "#fff",
            marginBottom: 10
          }}
          rightTitle={
            <View
              style={{
                marginBottom: 10,
                display: "flex",
                flexDirection: "column",
                alignItems: "center"
              }}
            >
              <Image
                style={{ width: 75, height: 75, borderRadius: 50 }}
                source={{ uri: item.images[0].url }}
              />
              <View
                style={{
                  marginTop: 15,
                  display: "flex",
                  flexDirection: "row",
                  alignItems: "center"
                }}
              >
                <Button
                  title="See event"
                  titleStyle={{
                    fontFamily: "Montserrat-SemiBold",
                    fontSize: 18,
                    padding: 0,
                    color: stridentRed
                  }}
                  buttonStyle={{
                    backgroundColor: "transparent",
                    padding: 0,
                    paddingTop: 8,
                    paddingBottom: 10
                  }}
                  onPress={() =>
                    this.props.navigation.navigate("EventView", {
                      item
                    })
                  }
                  containerStyle={{
                    backgroundColor: "transparent",
                    padding: 0,
                    marginTop: 5,
                    width: "90%",
                    borderTopWidth: 1,
                    borderTopColor: "#fff",
                    marginRight: 8
                  }}
                />
              </View>
            </View>
          }
          subtitle={
            <View style={{ display: "flex" }}>
              <View style={{ display: "flex" }}>
                <View
                  style={{
                    marginBottom: 10,
                    marginTop: 10,
                    display: "flex",
                    flexDirection: "row",
                    justifyContent: "flex-start",
                    alignItems: "center"
                  }}
                >
                  <AwesomeIcon
                    name="ad"
                    style={{
                      fontSize: 16,
                      paddingRight: 12,
                      color: stridentYellow
                    }}
                  />
                  <Text
                    style={{
                      fontSize: 16,
                      color: "#fff",
                      fontFamily: "Montserrat-SemiBold"
                    }}
                  >
                    {item.promoter && item.promoter.name}
                  </Text>
                </View>
                <View
                  style={{
                    marginBottom: 10,
                    display: "flex",
                    flexDirection: "row",
                    alignItems: "center"
                  }}
                >
                  <AwesomeIcon
                    name="map-marker-alt"
                    style={{
                      fontSize: 14,
                      paddingRight: 14,
                      color: stridentRed
                    }}
                  />
                  <Text
                    style={{
                      fontSize: 16,
                      color: "#fff",
                      fontFamily: "Montserrat-SemiBold"
                    }}
                  >
                    {item._embedded.venues[0].name}
                  </Text>
                </View>
              </View>

              <View
                style={{
                  marginBottom: 10,
                  display: "flex",
                  flexDirection: "row",
                  alignItems: "center"
                }}
              >
                <AwesomeIcon
                  name="calendar"
                  style={{
                    fontSize: 14,
                    paddingRight: 12,
                    color: "#fff"
                  }}
                />
                <Text
                  numberOfLines={2}
                  style={{
                    flex: 1,
                    flexWrap: "wrap",
                    fontSize: 16,
                    color: "#fff",
                    fontFamily: "Montserrat-Regular"
                  }}
                >
                  {item.dates.start.localDate}
                </Text>
              </View>
            </View>
          }
          key={item.id}
        />
        <Button
          buttonStyle={{
            backgroundColor: "transparent",
            width: "100%"
          }}
          title="Attend event"
          titleStyle={{
            fontSize: 15,
            color: "#FFF8F0",
            fontFamily: "Montserrat-Bold"
          }}
          onPress={this.addEvent}
          containerStyle={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            width: "80%",
            alignSelf: "center",
            position: "absolute",
            bottom: 20,
            borderRadius: 15,
            backgroundColor: "#B6174B",
            height: 40
          }}
        />
      </View>
    ) : (
      <LoadingScreen />
    );
  }
}

export default connect(
  state => ({
    route: state.routes.route,
    loading: state.routes.loading,
    currentUser: state.login.currentUser,
    item: state.routes.singleEvent
  }),
  { fetchEvent, attendEvent }
)(EventView);
