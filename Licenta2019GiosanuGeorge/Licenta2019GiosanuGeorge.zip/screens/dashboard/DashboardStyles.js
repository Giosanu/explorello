// import styled from "styled-components";
// import { Item, Form, Input, Label, Button, Text } from "native-base";

// export const DashboardForm = styled(Form)`
//   width: 100%;
//   height: 100%;
//   align-items: flex-start;
//   justify-content: center;
// `;

// export const DashboardInput = styled(Input)`
//   width: 100%;
// `;

// export const DashboardLabel = styled(Label)`
//   width: 100%;
// `;

// export const DashboardFormItem = styled(Item)`
//   display: flex;
//   width: 100%;
//   padding: 0;
//   align-items: center;
//   justify-content: flex-start;
// `;

// export const DashboardButton = styled(Button)`

// `
// export const DashboardText = styled(Text)`
// `