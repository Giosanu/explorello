import {
  SIGN_IN,
  SIGN_IN_SUCCESS,
  SIGN_IN_FAIL,
  STORE_USERNAME
} from "./LoginActions";
import { CLEAR_DATA } from "../user/UserActions";

const INITIAL_STATE = {
  loading: false,
  error: {},
  isAuthenticated: false,
  currentUser: {}
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case SIGN_IN:
      return { ...state, loading: true, error: {} };
    case SIGN_IN_SUCCESS:
      return {
        ...state,
        loading: false,
        error: {},
        isAuthenticated: true,
        currentUser: action.payload
      };
    case SIGN_IN_FAIL:
      return { ...state, loading: false, error: action.payload };
    case STORE_USERNAME:
      return {
        ...state,
        loading: false,
        currentUser: { ...state.currentUser, username: action.payload }
      };
    case CLEAR_DATA:
      return INITIAL_STATE;
    default:
      return state;
  }
};
