import { errorToast, successToast } from "../../constants/Functions";
import * as firebase from "react-native-firebase";

export const FETCH_ROUTES = "FETCH_ROUTES";
export const FETCH_ROUTES_SUCCESS = "FETCH_ROUTES_SUCCESS";
export const FETCH_ROUTES_FAIL = "FETCH_ROUTES_FAIL";

export const fetchRoutes = searchBy => dispatch => {
  dispatch({ type: FETCH_ROUTES });
  firebase
    .database()
    .ref("routes")
    .orderByChild("city")
    .startAt(`${searchBy}`)
    .endAt(`${searchBy}` + "\uf8ff")
    .once("value", function(snapshot) {
      console.log(snapshot.val());
      snapshot.val()
        ? dispatch({
            type: FETCH_ROUTES_SUCCESS,
            payload: snapshot.val()
          })
        : dispatch({
            type: FETCH_ROUTES_FAIL
          });
    });
};

export const FETCH_MY_ROUTES = "FETCH_MY_ROUTES";
export const FETCH_MY_ROUTES_SUCCESS = "FETCH_MY_ROUTES_SUCCESS";
export const FETCH_MY_ROUTES_FAIL = "FETCH_MY_ROUTES_FAIL";

export const fetchMyRoutes = uid => dispatch => {
  dispatch({ type: FETCH_MY_ROUTES });
  firebase
    .database()
    .ref("routes")
    .orderByChild("user/uid")
    .equalTo(uid)
    .once("value", function(snapshot) {
      snapshot.val()
        ? dispatch({
            type: FETCH_MY_ROUTES_SUCCESS,
            payload: snapshot.val()
          })
        : dispatch({
            type: FETCH_MY_ROUTES_FAIL
          });
    });
};

export const submitRating = (review, routeId, goBack) => dispatch => {
  var created_at = new Date();
  var dd = String(created_at.getDate()).padStart(2, "0");
  var mm = String(created_at.getMonth() + 1).padStart(2, "0"); //January is 0!
  var yyyy = created_at.getFullYear();

  created_at = mm + "/" + dd + "/" + yyyy;
  firebase
    .database()
    .ref(`routes/${routeId}/rating`)
    .once("value")
    .then(function(snapshot) {
      let update = {};
      update[`routes/${routeId}/rating/totalReviews`] =
        snapshot.val().totalReviews + 1;
      update[`routes/${routeId}/rating/total`] =
        (snapshot.val().totalScore + review.rating) /
        (snapshot.val().totalReviews + 1);
      update[`routes/${routeId}/rating/totalScore`] =
        snapshot.val().totalScore + review.rating;
      firebase
        .database()
        .ref()
        .update(update, function(error) {
          console.log(error);
        });
      firebase
        .database()
        .ref()
        .child(`routes/${routeId}/reviews`)
        .push()
        .set({ ...review, ...{ created_at } }, function(error) {
          if (error) {
            errorToast(`Something went wrong: ${error.message}`);
          } else {
            successToast(`Thank you for your feedback!`);
            dispatch(() => goBack());
          }
        });
    });
};

export const FETCH_REVIEWS = "FETCH_REVIEWS";
export const FETCH_REVIEWS_SUCCESS = "FETCH_REVIEWS_SUCCESS";
export const FETCH_REVIEWS_FAIL = "FETCH_REVIEWS_FAIL";

export const fetchReviews = routeId => dispatch => {
  dispatch({ type: FETCH_REVIEWS });
  firebase
    .database()
    .ref(`routes/${routeId}/reviews`)
    .once("value", function(snapshot) {
      snapshot.val()
        ? dispatch({
            type: FETCH_REVIEWS_SUCCESS,
            payload: snapshot.val()
          })
        : dispatch({
            type: FETCH_REVIEWS_FAIL
          });
    });
};

export const CHANGE_SEARCH_BY = "change_search_by";

export const changeSearchBy = searchBy => ({
  type: CHANGE_SEARCH_BY,
  payload: searchBy
});

export const FETCH_ROUTE = "FETCH_ROUTE";
export const FETCH_ROUTE_SUCCESS = "FETCH_ROUTE_SUCCESS";
export const FETCH_ROUTE_FAIL = "FETCH_ROUTE_FAIL";

export const fetchRoute = routeId => dispatch => {
  dispatch({ type: FETCH_ROUTE });
  firebase
    .database()
    .ref(`routes/${routeId}`)
    .once("value", function(snapshot) {
      console.log("LOL", snapshot.val());
      snapshot.val()
        ? dispatch({
            type: FETCH_ROUTE_SUCCESS,
            payload: { ...snapshot.val(), key: routeId }
          })
        : dispatch({
            type: FETCH_ROUTE_FAIL
          });
    });
};

export const FETCH_EVENTS = "FETCH_EVENTS";
export const FETCH_EVENTS_SUCCESS = "FETCH_EVENTS_SUCCESS";
export const FETCH_EVENTS_FAIL = "FETCH_EVENTS_FAIL";

export const fetchEvents = (pos, filter) => async dispatch => {
  dispatch({ type: FETCH_EVENTS });
  let url =
    "https://app.ticketmaster.com/discovery/v2/events.json?latlong=" +
    pos.latitude +
    "," +
    pos.longitude +
    `&apikey=ogNUXAvzuW7qUZ6AQWAJWaDwQAypzcbH&locale=*&endDateTime=2019-07-08T12:01:00Z&sort=relevance,desc${
      filter ? `&classificationName=${filter}` : ""
    }`;
  await fetch(url)
    .then(response => response.json())
    .then(responseJson => {
      dispatch({
        type: FETCH_EVENTS_SUCCESS,
        payload: responseJson._embedded.events
      });
    })
    .catch(err => {
      console.log(err);
      dispatch({
        type: FETCH_EVENTS_FAIL,
        error: err
      });
    });
};

export const MARK_COMPLETE = "MARK_COMPLETE";
export const MARK_COMPLETE_SUCCESS = "MARK_COMPLETE_SUCCESS";
export const MARK_COMPLETE_FAIL = "MARK_COMPLETE_FAIL";

export const markRouteComplete = (routeId, userId, navigate) => dispatch => {
  dispatch({ type: MARK_COMPLETE });
  let update = {};
  update[`users/${userId}/completed/${routeId}`] = "";
  firebase
    .database()
    .ref()
    .update(update, function(error) {
      if (error) {
        errorToast(`Something went wrong: ${error.message}`);
      } else {
        successToast(`Route added to your history.`);
        dispatch({
          type: MARK_COMPLETE_SUCCESS
        });
        dispatch(() => navigate("UserScreen"));
      }
    });
};

export const FETCH_EVENT = "FETCH_EVENT";
export const FETCH_EVENT_SUCCESS = "FETCH_EVENT_SUCCESS";
export const FETCH_EVENT_FAIL = "FETCH_EVENT_FAIL";

export const fetchEvent = (id, navigate) => async dispatch => {
  dispatch({ type: FETCH_EVENT });
  let url =
    "https://app.ticketmaster.com/discovery/v2/events/" +
    id +
    `?apikey=ogNUXAvzuW7qUZ6AQWAJWaDwQAypzcbH&locale=*`;
  await fetch(url)
    .then(response => response.json())
    .then(responseJson => {
      console.log("rrasdrasdfasdfasdfasdfasdfasdf", responseJson);
      dispatch({
        type: FETCH_EVENT_SUCCESS,
        payload: responseJson
      });
      dispatch(() => navigate("EventView"));
    })
    .catch(err => {
      console.log(err);
      dispatch({
        type: FETCH_EVENT_FAIL,
        error: err
      });
    });
};

export const attendEvent = (uid, event) => dispatch => {
  let update = {};
  let refr = firebase.database().ref(`users/${uid}/events`);
  let events;
  refr
    .once("value", snap => (events = snap.val()))
    .then(() => {
      console.log(events);
      events ? (update[`${events.length}`] = event) : (update[`0`] = event);
      refr.update(update, function(error) {
        if (error) {
          errorToast(`Something went wrong: ${error.message}`);
        } else {
          successToast(`Event added to your history.`);
        }
      });
    });
};

export const FETCH_MY_EVENTS = "FETCH_MY_EVENTS";
export const FETCH_MY_EVENTS_SUCCESS = "FETCH_MY_EVENTS_SUCCESS";
export const FETCH_MY_EVENTS_FAIL = "FETCH_MY_EVENTS_FAIL";

export const fetchMyEvents = uid => dispatch => {
  dispatch({ type: FETCH_MY_EVENTS });
  firebase
    .database()
    .ref(`users/${uid}/events`)
    .once("value", function(snapshot) {
      snapshot.val()
        ? dispatch({
            type: FETCH_MY_EVENTS_SUCCESS,
            payload: snapshot.val()
          })
        : dispatch({
            type: FETCH_MY_EVENTS_FAIL
          });
    });
};

export const FETCH_COMPLETED = "FETCH_COMPLETED";
export const ADD_COMPLETED = "ADD_COMPLETED";
export const FETCH_COMPLETED_FAIL = "FETCH_COMPLETED_FAIL";
export const FETCH_COMPLETED_SUCCESS = "FETCH_COMPLETED_SUCCESS";

export const fetchCompletedRoutes = uid => dispatch => {
  dispatch({
    type: FETCH_COMPLETED
  });
  firebase
    .database()
    .ref(`users/${uid}/completed`)
    .once("value", function(snapshot) {
      Object.keys(snapshot.val()).map((key, index) =>
        firebase
          .database()
          .ref(`routes/${key}`)
          .once("value", snap => {
            dispatch({
              type: ADD_COMPLETED,
              payload: { ...snap.val(), ...{ key } }
            });
            if (index === Object.keys(snapshot.val()).length - 1) {
              dispatch({
                type: FETCH_COMPLETED_SUCCESS
              });
            }
          })
      );
    });
};
