import React from "react";
import { View, Text, Image, ScrollView, TouchableOpacity } from "react-native";
import { Button, ListItem, Input, AirbnbRating } from "react-native-elements";
import { connect } from "react-redux";
import AwesomeIcon from "react-native-vector-icons/FontAwesome5";
import Geolocation from "react-native-geolocation-service";
import { navigationOptions } from "../../constants/headerStyles";
import MapView, { Marker, PROVIDER_GOOGLE } from "react-native-maps";
import MapViewDirections from "react-native-maps-directions";
import Icon from "react-native-vector-icons/MaterialCommunityIcons";
import {
  stridentRed,
  primaryBlue,
  stridentYellow,
  primaryYellow,
  primaryRed
} from "../../constants/Colors";
import { GoogleApiKey } from "../../config/keys";
import { mapStyle } from "../../constants/Styles";
import {
    fetchCompletedRoutes,
  fetchMyEvents
} from "../routes/RoutesActions";
import LoadingScreen from "../LoadingScreen";
import { successToast } from "../../constants/Functions";

class MapHistory extends React.Component {
  componentDidMount() {
    const {
      currentUser,
      fetchMyEvents,
      fetchCompletedRoutes,
      navigation
    } = this.props;
    fetchMyEvents(currentUser.uid);
    fetchCompletedRoutes(currentUser.uid);
  }
  static navigationOptions = {
    ...navigationOptions,
    ...{
      headerLeft: props => {
        return (
          <Button
            containerStyle={{ backgroundColor: "transparent" }}
            buttonStyle={{ backgroundColor: "transparent" }}
            title=""
            onPress={props.onPress}
            icon={
              <Icon name="arrow-left" style={{ color: "#fff", fontSize: 24 }} />
            }
          />
        );
      },
      headerRight: <View />
    }
  };
  state = {
    showDetails: false,
    mapLoading: true,
    location: null
  };
  completeRoute = () => {
    successToast("Event added to your history map!");
  };
  render() {
    const { myEvents, completed } = this.props; //|| this.props.navigation.state.params.item;
    const { mapLoading, showDetails, location } = this.state;
    return !this.props.loading ? (
      <View style={{ flex: 1, position: "relative" }}>
        <MapView
          provider={PROVIDER_GOOGLE}
          showsMyLocationButton={false}
          onMapReady={() => this.setState({ mapLoading: false })}
          loadingEnabled={true}
          region={location}
          loadingIndicatorColor={primaryYellow}
          style={{
            width: "100%",
            height: "100%",
            top: mapLoading ? "-100%" : 0,
            position: "absolute"
          }}
          onRegionChangeComplete={location => this.setState({ location })}
          customMapStyle={mapStyle}
        >
          {completed &&
            completed.map((route, index) => (
                route.route.markers.length > 0 && <MapViewDirections
                strokeWidth={6}
                key={index}
                strokeColor={primaryRed}
                mode="WALKING"
                onError={error => errorToast(error)}
                origin={route.route.markers[0]}
                waypoints={route.route.markers.map(
                  (m, i) => (i !== 0 || i !== route.route.markers.length) && m
                )}
                destination={route.route.markers[route.route.markers.length - 1]}
                apikey={GoogleApiKey}
              />
            ))}
          {completed &&
            completed.map((route, index) =>
            route.route.markers.length > 0 && route.route.markers.map((marker, ind) => (
                <Marker
                  coordinate={marker}
                  key={ind}
                  title={`Point ${ind + 1}`}
                  description={marker.description || ""}
                  tracksViewChanges={false}
                  pinColor={
                    (ind === 0 && stridentRed) ||
                    (ind !== route.route.markers.length - 1 && primaryBlue) ||
                    primaryYellow
                  }
                />
              ))
            )}
          {myEvents &&
            myEvents.map((event, index) => (
              <Marker
                coordinate={event.position}
                key={index}
                title={`${event.name}`}
                description={event.description || ""}
                tracksViewChanges={false}
                pinColor="indigo"
              />
            ))}
        </MapView>
      </View>
    ) : (
      <LoadingScreen />
    );
  }
}

export default connect(
  state => ({
    route: state.routes.route,
    loading: state.routes.loading,
    completed: state.routes.completed,
    myEvents: state.routes.myEvents,
    currentUser: state.login.currentUser,
    item: state.routes.singleEvent
  }),
  { fetchMyEvents, fetchCompletedRoutes }
)(MapHistory);
