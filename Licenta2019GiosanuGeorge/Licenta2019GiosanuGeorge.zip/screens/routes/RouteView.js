import React from "react";
import {
  View,
  Text,
  ImageBackground,
  ScrollView,
  TouchableOpacity
} from "react-native";
import { Button, ListItem, Input, AirbnbRating } from "react-native-elements";
import { connect } from "react-redux";
import AwesomeIcon from "react-native-vector-icons/FontAwesome5";
import { navigationOptions } from "../../constants/headerStyles";
import MapView, { Marker, PROVIDER_GOOGLE } from "react-native-maps";
import MapViewDirections from "react-native-maps-directions";
import Icon from "react-native-vector-icons/MaterialCommunityIcons";
import {
  stridentRed,
  primaryBlue,
  stridentYellow,
  primaryYellow,
  primaryRed
} from "../../constants/Colors";
import { GoogleApiKey } from "../../config/keys";
import { mapStyle } from "../../constants/Styles";
import { fetchRoute, markRouteComplete } from "./RoutesActions";
import LoadingScreen from "../LoadingScreen";

class RouteView extends React.Component {
  componentDidMount() {
    const { fetchRoute, navigation } = this.props;
    fetchRoute(navigation.state.params.item.key);
    
  }
  static navigationOptions = {
    ...navigationOptions,
    ...{
      headerLeft: props => {
        return (
          <Button
            containerStyle={{ backgroundColor: "transparent" }}
            buttonStyle={{ backgroundColor: "transparent" }}
            title=""
            onPress={props.onPress}
            icon={
              <Icon name="arrow-left" style={{ color: "#fff", fontSize: 24 }} />
            }
          />
        );
      },
      headerRight: <View />
    }
  };
  state = {
    showDetails: false,
    mapLoading: true,
    location: null
  };
  completeRoute = () => {
    const { currentUser, navigation } = this.props;
    this.props.markRouteComplete(navigation.state.params.item.key, currentUser.uid, navigation.navigate);
  };
  render() {
    const { route } = this.props; //|| this.props.navigation.state.params.item;
    const { markers } = route.route;
    const { routeCenter } = route;
    const { mapLoading, showDetails, location } = this.state;
    return !this.props.loading ? (
      <View style={{ flex: 1, position: "relative" }}>
        <MapView
          provider={PROVIDER_GOOGLE}
          showsMyLocationButton={false}
          onMapReady={() => this.setState({ mapLoading: false })}
          loadingEnabled={true}
          loadingIndicatorColor={primaryYellow}
          region={location || routeCenter}
          style={{
            width: "100%",
            height: "100%",
            top: mapLoading ? "-100%" : 0,
            position: "absolute"
          }}
          onRegionChangeComplete={location => this.setState({ location })}
          customMapStyle={mapStyle}
        >
          {markers.length > 0 && (
            <MapViewDirections
              strokeWidth={6}
              strokeColor={primaryRed}
              mode="WALKING"
              onError={error => errorToast(error)}
              origin={markers[0]}
              waypoints={markers.map(
                (m, i) => (i !== 0 || i !== markers.length) && m
              )}
              destination={markers[markers.length - 1]}
              apikey={GoogleApiKey}
            />
          )}
          {markers.map((marker, index) => (
            <Marker
              coordinate={marker}
              key={index}
              title={`Point ${index + 1}`}
              description={marker.description || ""}
              tracksViewChanges={false}
              pinColor={
                (index === 0 && stridentRed) ||
                (index !== markers.length - 1 && primaryBlue) ||
                primaryYellow
              }
            />
          ))}
        </MapView>
        <ListItem
          title={route.name}
          containerStyle={{
            backgroundColor: showDetails ? "#14445A" : stridentYellow,
            top: 0,
            position: "absolute"
          }}
          rightContentContainerStyle={{
            display: "flex",
            height: "100%",
            borderLeftColor: showDetails ? "#eee" : primaryBlue,
            paddingTop: 3,
            borderLeftWidth: 0.5,
            paddingLeft: 10,
            justifyContent: "flex-start"
          }}
          contentContainerStyle={{
            paddingRight: 10,
            height: "100%",
            display: "flex",
            justifyContent: "flex-start"
          }}
          titleStyle={{
            fontFamily: "Montserrat-Light",
            fontSize: 20,
            color: showDetails ? "#fff" : "#14445A",
            marginBottom: 10
          }}
          rightTitle={
            showDetails ? (
              <View style={{ alignSelf: "flex-end" }}>
                <AirbnbRating
                  showRating={false}
                  defaultRating={route.rating.total}
                  size={16}
                />
              </View>
            ) : (
              <View />
            )
          }
          rightSubtitle={
            showDetails ? (
              <View style={{ display: "flex" }}>
                <View
                  style={{
                    marginTop: 10,
                    display: "flex",
                    flexDirection: "row",
                    justifyContent: "flex-end",
                    alignItems: "center"
                  }}
                >
                  <Text
                    style={{
                      fontSize: 16,
                      color: "#fff",
                      fontFamily: "Montserrat-SemiBold"
                    }}
                  >
                    {route.rating.totalReviews} reviews
                  </Text>
                  <AwesomeIcon
                    name="users"
                    style={{
                      fontSize: 16,
                      paddingLeft: 12,
                      color: "#fff"
                    }}
                  />
                </View>
                <View
                  style={{
                    marginBottom: 10,
                    marginTop: 10,
                    display: "flex",
                    flexDirection: "row",
                    justifyContent: "flex-end",
                    alignItems: "center"
                  }}
                >
                  <Text
                    style={{
                      fontSize: 16,
                      color: "#fff",
                      fontFamily: "Montserrat-SemiBold"
                    }}
                  >
                    {route.duration}
                  </Text>
                  <AwesomeIcon
                    name="walking"
                    style={{
                      fontSize: 16,
                      paddingLeft: 12,
                      color: "#fff"
                    }}
                  />
                </View>
                <View
                  style={{
                    paddingBottom: 10,
                    display: "flex",
                    justifyContent: "flex-end",
                    flexDirection: "row",
                    alignItems: "center"
                    // borderBottomWidth: 0.5,
                    // borderBottomColor: "#fff"
                  }}
                >
                  <Text
                    style={{
                      fontSize: 16,
                      color: "#fff",
                      fontFamily: "Montserrat-SemiBold"
                    }}
                  >
                    {route.distance}
                  </Text>
                  <AwesomeIcon
                    name="ruler"
                    style={{
                      fontSize: 16,
                      paddingLeft: 10,
                      color: "#fff"
                    }}
                  />
                </View>
                <Button
                  onPress={() => this.setState({ showDetails: !showDetails })}
                  title="Hide details"
                  icon={
                    <AwesomeIcon
                      style={{
                        fontSize: 12,
                        textAlign: "center",
                        borderRadius: 30,
                        marginRight: 5,
                        backgroundColor: "#14445A",
                        color: "#fff"
                      }}
                      name="chevron-up"
                    />
                  }
                  titleStyle={{
                    fontFamily: "Montserrat-Bold",
                    fontSize: 14,
                    padding: 0,
                    color: "#fff"
                  }}
                  buttonStyle={{
                    backgroundColor: "transparent",
                    padding: 0,
                    paddingTop: 8,
                    paddingBottom: 10
                  }}
                  containerStyle={{
                    backgroundColor: "transparent",
                    padding: 0,
                    paddingTop: 10,
                    borderTopColor: "#fff",
                    borderTopWidth: 0.5,
                    alignSelf: "flex-end",
                    marginTop: 10,
                    marginRight: 8
                  }}
                />
              </View>
            ) : (
              <Button
                onPress={() => this.setState({ showDetails: !showDetails })}
                title="Show details"
                icon={
                  <AwesomeIcon
                    style={{
                      fontSize: 16,
                      textAlign: "center",
                      borderRadius: 30,
                      marginRight: 5,
                      backgroundColor: stridentYellow,
                      color: primaryBlue
                    }}
                    name="chevron-down"
                  />
                }
                titleStyle={{
                  fontFamily: "Montserrat-SemiBold",
                  fontSize: 16,
                  padding: 0,
                  color: primaryBlue
                }}
                buttonStyle={{
                  backgroundColor: "transparent",
                  padding: 0,
                  paddingBottom: 10
                }}
                containerStyle={{
                  backgroundColor: "transparent",
                  padding: 0,
                  alignSelf: "flex-end",
                  marginRight: 8
                }}
              />
            )
          }
          subtitle={
            showDetails ? (
              <View style={{ display: "flex" }}>
                <View
                  style={{
                    marginBottom: 10,
                    display: "flex",
                    flexDirection: "row",
                    alignItems: "center"
                  }}
                >
                  <AwesomeIcon
                    name="map-marker-alt"
                    style={{
                      fontSize: 16,
                      paddingRight: 10,
                      color: stridentRed
                    }}
                  />
                  <Text
                    style={{
                      fontSize: 16,
                      color: "#fff",
                      fontFamily: "Montserrat-Regular"
                    }}
                  >
                    {route.city}
                  </Text>
                </View>
                <View
                  style={{
                    display: "flex",
                    marginBottom: 10,
                    flexDirection: "row",
                    maxHeight: 150,
                    alignItems: "center",
                    flex: 1
                  }}
                >
                  <AwesomeIcon
                    name="info-circle"
                    style={{
                      fontSize: 16,
                      paddingRight: 8,
                      color: "#fff"
                    }}
                  />
                  <TouchableOpacity
                    style={{
                      display: "flex",
                      flex: 1
                    }}
                  >
                    <ScrollView
                      contentContainerStyle={{
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "center"
                      }}
                    >
                      <Text
                        style={{
                          flex: 1,
                          flexWrap: "wrap",
                          fontSize: 16,
                          color: "#fff",
                          fontFamily: "Montserrat-Regular"
                        }}
                      >
                        {route.description}
                      </Text>
                    </ScrollView>
                  </TouchableOpacity>
                </View>
                <View
                  style={{
                    marginBottom: 10,
                    display: "flex",
                    flexDirection: "row",
                    alignItems: "center"
                  }}
                >
                  <AwesomeIcon
                    name="user-alt"
                    style={{
                      fontSize: 16,
                      paddingRight: 8,
                      color: "#fff"
                    }}
                  />
                  <Text
                    style={{
                      fontSize: 16,
                      color: stridentYellow,
                      fontFamily: "Montserrat-SemiBold"
                    }}
                  >
                    by {route.user.username}
                  </Text>
                </View>
                <View
                  style={{
                    marginBottom: 10,
                    display: "flex",
                    borderTopColor: "#fff",
                    borderTopWidth: 0.5,
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center"
                  }}
                >
                  <Button
                    onPress={() =>
                      this.props.navigation.navigate("AllReviews", route)
                    }
                    title="All reviews"
                    icon={
                      <AwesomeIcon
                        style={{
                          fontSize: 16,
                          textAlign: "center",
                          borderRadius: 30,
                          marginRight: 5,
                          backgroundColor: "#14445A",
                          color: stridentYellow
                        }}
                        name="comments"
                      />
                    }
                    titleStyle={{
                      fontFamily: "Montserrat-SemiBold",
                      fontSize: 16,
                      padding: 0,
                      color: stridentYellow
                    }}
                    buttonStyle={{
                      backgroundColor: "transparent",
                      padding: 0,
                      paddingBottom: 10
                    }}
                    containerStyle={{
                      backgroundColor: "transparent",
                      padding: 0,
                      paddingTop: 9,
                      alignSelf: "flex-end",
                      marginTop: 5,
                      marginRight: 8
                    }}
                  />
                  <Button
                    onPress={() =>
                      this.props.navigation.navigate("AddReview", route)
                    }
                    title="Rate route"
                    icon={
                      <AwesomeIcon
                        style={{
                          fontSize: 16,
                          textAlign: "center",
                          borderRadius: 30,
                          marginRight: 5,
                          backgroundColor: "#14445A",
                          color: primaryRed
                        }}
                        name="plus"
                      />
                    }
                    titleStyle={{
                      fontFamily: "Montserrat-SemiBold",
                      fontSize: 16,
                      padding: 0,
                      color: primaryRed
                    }}
                    buttonStyle={{
                      backgroundColor: "transparent",
                      padding: 0,
                      paddingTop: 3,
                      paddingBottom: 10
                    }}
                    containerStyle={{
                      backgroundColor: "transparent",
                      padding: 0,
                      paddingTop: 10,
                      alignSelf: "flex-end",
                      marginRight: 8
                    }}
                  />
                </View>
              </View>
            ) : (
              <View />
            )
          }
          key={route.key}
        />
        {showDetails && (
          <Button
            buttonStyle={{
              backgroundColor: "transparent",
              width: "100%"
            }}
            title="Mark route complete"
            titleStyle={{
              fontSize: 15,
              color: "#FFF8F0",
              fontFamily: "Montserrat-Bold"
            }}
            onPress={this.completeRoute}
            containerStyle={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              width: "80%",
              alignSelf: "center",
              position: "absolute",
              bottom: 20,
              borderRadius: 15,
              backgroundColor: "#B6174B",
              height: 40
            }}
          />
        )}
      </View>
    ) : (
      <LoadingScreen />
    );
  }
}

export default connect(
  state => ({
    route: state.routes.route,
    loading: state.routes.loading,
    currentUser: state.login.currentUser
  }),
  { fetchRoute, markRouteComplete }
)(RouteView);
