import { createAppContainer, createStackNavigator } from "react-navigation";
import RoutesScreen from "./RoutesScreen";
import RouteView from "./RouteView";
import AddReview from "./AddReview";
import AllReviews from "./AllReviews";
import EventsScreen from "../dashboard/EventsScreen";
import EventView from "../dashboard/EventView";
import MyRoutes from "./MyRoutes";
import MapHistory from "./MapHistory";
import TravelHistory from "./TravelHistory";

export default createAppContainer(
  createStackNavigator({
    RoutesScreen: { screen: RoutesScreen },
    MyRoutes: { screen: MyRoutes },
    RouteView: { screen: RouteView },
    AddReview: { screen: AddReview },
    MapHistory: { screen: MapHistory },
    EventsScreen: { screen: EventsScreen },
    TravelHistory: { screen: TravelHistory },
    EventView: { screen: EventView },
    AllReviews: { screen: AllReviews }
  })
);
