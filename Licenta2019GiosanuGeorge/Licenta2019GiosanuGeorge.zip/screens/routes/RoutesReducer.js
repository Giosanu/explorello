import {
  FETCH_ROUTES,
  FETCH_ROUTES_SUCCESS,
  FETCH_ROUTES_FAIL,
  FETCH_MY_ROUTES,
  FETCH_MY_ROUTES_SUCCESS,
  FETCH_MY_ROUTES_FAIL,
  FETCH_REVIEWS,
  FETCH_REVIEWS_SUCCESS,
  FETCH_ROUTE,
  FETCH_ROUTE_SUCCESS,
  FETCH_ROUTE_FAIL,
  CHANGE_SEARCH_BY,
  FETCH_EVENTS,
  FETCH_EVENTS_SUCCESS,
  FETCH_EVENTS_FAIL,
  FETCH_EVENT,
  FETCH_EVENT_SUCCESS,
  FETCH_EVENT_FAIL,
  FETCH_MY_EVENTS,
  FETCH_MY_EVENTS_SUCCESS,
  FETCH_MY_EVENTS_FAIL,
  FETCH_COMPLETED,
  FETCH_COMPLETED_FAIL,
  FETCH_COMPLETED_SUCCESS,
  ADD_COMPLETED
} from "./RoutesActions";
import { CLEAR_DATA } from "../user/UserActions";

const INITIAL_STATE = {
  loading: false,
  error: {},
  routes: [],
  events: [],
  currentUser: {},
  route: {
    route: {
      markers: []
    }
  },
  singleEvent: {},
  reviews: [],
  searchBy: "",
  singleRoute: {},
  myEvents: null,
  myRoutes: null,
  completed: []
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case FETCH_ROUTES:
      return { ...state, loading: true, error: {} };
    case FETCH_ROUTES_SUCCESS:
      let routes = [];
      Object.keys(action.payload).map(key =>
        routes.push({ ...action.payload[key], ...{ key } })
      );
      return { ...state, loading: false, error: {}, routes };
    case FETCH_ROUTES_FAIL:
      return { ...state, loading: false, error: action.payload, routes: null };

    case FETCH_MY_ROUTES:
      return { ...state, loading: true, error: {} };
    case FETCH_MY_ROUTES_SUCCESS:
      let myRoutes = [];
      Object.keys(action.payload).map(key =>
        myRoutes.push({ ...action.payload[key], ...{ key } })
      );
      return { ...state, loading: false, error: {}, myRoutes };
    case FETCH_MY_ROUTES_FAIL:
      return {
        ...state,
        loading: false,
        error: action.payload,
        myRoutes: null
      };

    case FETCH_REVIEWS:
      return { ...state, loading: true };
    case FETCH_REVIEWS_SUCCESS:
      let reviews = [];
      Object.keys(action.payload).map(key =>
        reviews.push({ ...action.payload[key], ...{ key } })
      );
      return { ...state, loading: false, reviews };

    case CHANGE_SEARCH_BY:
      return { ...state, searchBy: action.payload };

    case FETCH_ROUTE:
      return { ...state, loading: true, error: {} };
    case FETCH_ROUTE_SUCCESS:
      return { ...state, loading: false, error: {}, route: action.payload };
    case FETCH_ROUTE_FAIL:
      return { ...state, loading: false, error: action.payload, route: null };

    case FETCH_EVENTS:
      return { ...state, loading: true, error: {} };
    case FETCH_EVENTS_SUCCESS:
      return { ...state, loading: false, error: {}, events: action.payload };
    case FETCH_EVENTS_FAIL:
      return { ...state, loading: false, error: action.payload, events: [] };

    case FETCH_EVENT:
      return { ...state, loading: true, error: {} };
    case FETCH_EVENT_SUCCESS:
      return {
        ...state,
        loading: false,
        error: {},
        singleEvent: action.payload
      };
    case FETCH_EVENT_FAIL:
      return {
        ...state,
        loading: false,
        error: action.payload,
        singleEvent: {}
      };

    case FETCH_MY_EVENTS:
      return { ...state, error: {} };
    case FETCH_MY_EVENTS_SUCCESS:
      return { ...state, error: {}, myEvents: action.payload };
    case FETCH_MY_EVENTS_FAIL:
      return { ...state, error: action.payload, myEvents: [] };

    case FETCH_COMPLETED:
      return { ...state, loading: true, error: {}, completed: [] };
    case ADD_COMPLETED:
      let completed = [...state.completed, ...[action.payload]];
      return { ...state, completed };
    case FETCH_COMPLETED_SUCCESS:
      return { ...state, loading: false, error: {} };
    case FETCH_COMPLETED_FAIL:
      return {
        ...state,
        loading: false,
        error: action.payload,
        completed: []
      };

    case CLEAR_DATA:
      return INITIAL_STATE;
    default:
      return state;
  }
};
