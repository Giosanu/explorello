import React from "react";
import { View, StyleSheet, Text, TextInput } from "react-native";
import { connect } from "react-redux";
import { navigationOptions } from "../../constants/headerStyles";
import Icon from "react-native-vector-icons/MaterialCommunityIcons";
import AwesomeIcon from "react-native-vector-icons/FontAwesome5";
import {
  stridentRed,
  primaryBlue,
  stridentYellow,
  primaryYellow,
  primaryRed
} from "../../constants/Colors";
import { Button, ListItem, Input, AirbnbRating } from "react-native-elements";
import {submitRating} from './RoutesActions'

let goBack;

class AddReview extends React.Component {
  state = {
    description: "",
    rating: 5
  };
  static navigationOptions = {
    ...navigationOptions,
    ...{
      headerLeft: props => {
        goBack = props.onPress;
        return (
          <Button
            containerStyle={{ backgroundColor: "transparent" }}
            buttonStyle={{ backgroundColor: "transparent" }}
            title=""
            onPress={props.onPress}
            icon={
              <Icon name="arrow-left" style={{ color: "#fff", fontSize: 24 }} />
            }
          />
        );
      },
      headerRight: <View />
    }
  };
  componentDidMount() {
    // check if review exists
  }
  submitRating = () => {
    const { submitRating, currentUser } = this.props;
    const key = this.props.navigation.state.params.key
    console.log(this.props.navigation.state.params, "lol lol lol")
    const { description, rating } = this.state;
    submitRating(
      {
        description,
        rating,
        user: currentUser
      },
      key,
      goBack
    );
  };
  render() {
    const item = this.props.navigation.state.params;
    const { description, rating } = this.state;
    return (
      <View style={styles.container}>
        <Text
          style={{
            fontFamily: "Montserrat-SemiBold",
            color: "#fff",
            width: "100%",
            textAlign: "center",
            fontSize: 22,
            marginTop: 20,
            marginBottom: 20
          }}
        >
          {item.name}
        </Text>
        <AirbnbRating
          size={32}
          showRating={false}
          defaultRating={5}
          onFinishRating={rating => this.setState({ rating })}
        />
        <Text
          style={{
            fontFamily: "Montserrat-SemiBold",
            color: stridentRed,
            width: "100%",
            textAlign: "center",
            fontSize: 24,
            paddingTop: 10,
            paddingBottom: 5
          }}
        >
          {rating} / 5
        </Text>
        <Text
          style={{
            marginTop: 20,
            textAlign: "center",
            fontSize: 18,
            backgroundColor: "#14445A",
            paddingTop: 5,
            paddingBottom: 5,
            marginLeft: 20,
            marginRight: 20,
            borderColor: primaryYellow,
            borderWidth: 1,
            fontFamily: "Montserrat-Bold",
            color: primaryYellow
          }}
        >
          Would you explain your score?
        </Text>
        <TextInput
          style={{
            backgroundColor: primaryYellow,
            color: primaryBlue,
            fontSize: 20,
            fontFamily: "Montserrat-Regular",
            paddingTop: 5,
            paddingRight: 40,
            maxHeight: 250,
            paddingLeft: 40,
            marginLeft: 20,
            marginRight: 20,
            flex: 1,
            borderBottomLeftRadius: 15,
            borderBottomRightRadius: 15,
            minHeight: 100
          }}
          secureTextEntry={
            this.state.description.length <= 0 &&
            this.state.descriptionStatus != "onFocus"
              ? true
              : false
          }
          multiline
          onChangeText={description => this.setState({ description })}
          placeholderTextColor={"#444"}
          placeholder={
            "Example: I wouldn't put restaurant X in this route, but rather restaurant Y and coffee shop Z..."
          }
          numberOfLines={4}
        />
        <Button
          title="Submit rating"
          titleStyle={{
            fontFamily: "Montserrat-SemiBold",
            color: "#fff",
            fontSize: 18
          }}
          onPress={this.submitRating}
          buttonStyle={{ backgroundColor: "transparent" }}
          containerStyle={{
            backgroundColor: primaryRed,
            marginLeft: 20,
            marginTop: 30,
            marginBottom: 20,
            marginRight: 20,
            height: 45,
            borderRadius: 25
          }}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: primaryBlue
  }
});

export default connect(
  state => ({
    currentUser: state.login.currentUser
  }),
  {submitRating}
)(AddReview);
