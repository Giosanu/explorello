import React from "react";
import { View, Text, FlatList } from "react-native";
import {
  Input,
  Button,
  ListItem,
  Rating,
  AirbnbRating
} from "react-native-elements";
import { NavigationEvents } from "react-navigation";
import { navigationOptions } from "../../constants/headerStyles";
import Icon from "react-native-vector-icons/MaterialCommunityIcons";
import AwesomeIcon from "react-native-vector-icons/FontAwesome5";
import {
  primaryBlue,
  stridentRed,
  stridentYellow,
  primaryRed
} from "../../constants/Colors";
import { GoogleApiKey } from "../../config/keys";
import { connect } from "react-redux";
import { fetchCompletedRoutes, changeSearchBy } from "./RoutesActions";
import LoadingScreen from "../LoadingScreen";

class TravelHistory extends React.Component {
  static navigationOptions = {
    ...navigationOptions,
    ...{
      headerLeft: props => {
        return (
          <Button
            containerStyle={{ backgroundColor: "transparent" }}
            buttonStyle={{ backgroundColor: "transparent" }}
            title=""
            onPress={props.onPress}
            icon={
              <Icon name="arrow-left" style={{ color: "#fff", fontSize: 24 }} />
            }
          />
        );
      },
      headerRight: <View />
    }
  };
  componentDidMount() {
    this.props.fetchCompletedRoutes(this.props.currentUser.uid);
  }
  render() {
    const { completed } = this.props;
    return (
      !this.props.loading ? <View style={{ flex: 1, backgroundColor: primaryBlue }}>
        {completed && (
          <FlatList
            data={completed}
            renderItem={({ item }) => (
              <ListItem
                title={item.name}
                containerStyle={{
                  backgroundColor: "transparent",
                  borderBottomColor: "#fff",
                  borderBottomWidth: 1
                }}
                rightContentContainerStyle={{
                  display: "flex",
                  height: "100%",
                  borderLeftColor: "#eee",
                  paddingTop: 3,
                  borderLeftWidth: 1,
                  marginLeft: 10,
                  paddingLeft: 10,
                  justifyContent: "flex-start"
                }}
                leftContentContainerStyle={{
                  paddingRight: 10
                }}
                titleStyle={{
                  fontFamily: "Montserrat-Light",
                  fontSize: 20,
                  color: "#fff",
                  marginBottom: 10
                }}
                rightTitle={
                  <View style={{ alignSelf: "flex-end" }}>
                    <AirbnbRating
                      showRating={false}
                      defaultRating={item.rating.total}
                      size={16}
                    />
                  </View>
                }
                rightSubtitle={
                  <View style={{ display: "flex" }}>
                    <View
                      style={{
                        marginBottom: 10,
                        marginTop: 10,
                        display: "flex",
                        flexDirection: "row",
                        justifyContent: "flex-end",
                        alignItems: "center"
                      }}
                    >
                      <Text
                        style={{
                          fontSize: 16,
                          color: "#fff",
                          fontFamily: "Montserrat-SemiBold"
                        }}
                      >
                        {item.duration}
                      </Text>
                      <AwesomeIcon
                        name="walking"
                        style={{
                          fontSize: 14,
                          paddingLeft: 16,
                          color: "#fff"
                        }}
                      />
                    </View>
                    <View
                      style={{
                        marginBottom: 10,
                        display: "flex",
                        justifyContent: "flex-end",
                        flexDirection: "row",
                        alignItems: "center"
                      }}
                    >
                      <Text
                        style={{
                          fontSize: 16,
                          color: "#fff",
                          fontFamily: "Montserrat-SemiBold"
                        }}
                      >
                        {item.distance}
                      </Text>
                      <AwesomeIcon
                        name="ruler"
                        style={{
                          fontSize: 16,
                          paddingLeft: 10,
                          color: "#fff"
                        }}
                      />
                    </View>
                    <View
                      style={{
                        marginBottom: 10,
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "center"
                      }}
                    >
                      <Button
                        title="See route"
                        titleStyle={{
                          fontFamily: "Montserrat-SemiBold",
                          fontSize: 18,
                          padding: 0,
                          color: stridentRed
                        }}
                        buttonStyle={{
                          backgroundColor: "transparent",
                          padding: 0,
                          paddingTop: 8,
                          paddingBottom: 10
                        }}
                        onPress={() =>
                          this.props.navigation.navigate("RouteView", { item })
                        }
                        containerStyle={{
                          backgroundColor: "transparent",
                          padding: 0,
                          marginTop: 5,
                          width: "90%",
                          borderTopWidth: 1,
                          borderTopColor: "#fff",
                          marginRight: 8
                        }}
                      />
                    </View>
                  </View>
                }
                subtitle={
                  <View style={{ display: "flex" }}>
                    <View
                      style={{
                        marginBottom: 10,
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "center"
                      }}
                    >
                      <AwesomeIcon
                        name="map-marker-alt"
                        style={{
                          fontSize: 16,
                          paddingRight: 10,
                          color: stridentRed
                        }}
                      />
                      <Text
                        style={{
                          fontSize: 16,
                          color: "#fff",
                          fontFamily: "Montserrat-Regular"
                        }}
                      >
                        {item.city}
                      </Text>
                    </View>
                    <View
                      style={{
                        marginBottom: 10,
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "center"
                      }}
                    >
                      <AwesomeIcon
                        name="info-circle"
                        style={{
                          fontSize: 16,
                          paddingRight: 8,
                          color: "#fff"
                        }}
                      />
                      <Text
                        numberOfLines={2}
                        style={{
                          flex: 1,
                          flexWrap: "wrap",
                          fontSize: 16,
                          color: "#fff",
                          fontFamily: "Montserrat-Regular"
                        }}
                      >
                        {item.description}
                      </Text>
                    </View>
                    <View
                      style={{
                        marginBottom: 10,
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "center"
                      }}
                    >
                      <AwesomeIcon
                        name="user-alt"
                        style={{
                          fontSize: 16,
                          paddingRight: 8,
                          color: "#fff"
                        }}
                      />
                      <Text
                        style={{
                          fontSize: 16,
                          color: stridentYellow,
                          fontFamily: "Montserrat-SemiBold"
                        }}
                      >
                        by You
                      </Text>
                    </View>
                  </View>
                }
                key={item.key}
              >
                {item.key}
              </ListItem>
            )}
          />
        )}
      </View> : <LoadingScreen />
    );
  }
}

export default connect(
  state => ({
    searchBy: state.routes.searchBy,
    completed: state.routes.completed,
    loading: state.routes.loading,
    currentUser: state.login.currentUser
  }),
  { fetchCompletedRoutes, changeSearchBy }
)(TravelHistory);
