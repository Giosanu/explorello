import React from "react";
import { View, Text, FlatList } from "react-native";
import {
  Input,
  Button,
  ListItem,
  Rating,
  AirbnbRating
} from "react-native-elements";
import { NavigationEvents } from "react-navigation";
import { navigationOptions } from "../../constants/headerStyles";
import Icon from "react-native-vector-icons/MaterialCommunityIcons";
import AwesomeIcon from "react-native-vector-icons/FontAwesome5";
import {
  primaryBlue,
  stridentRed,
  stridentYellow,
  primaryRed
} from "../../constants/Colors";
import { GoogleApiKey } from "../../config/keys";
import { connect } from "react-redux";
import { fetchRoutes, changeSearchBy } from "./RoutesActions";
import LoadingScreen from "../LoadingScreen";

class RoutesScreen extends React.Component {
  static navigationOptions = navigationOptions;
  componentDidMount() {
    this.props.changeSearchBy("");
  }
  fetchRoutes = () => {
    const { fetchRoutes, searchBy } = this.props;
    setTimeout(() => fetchRoutes(searchBy), 1500);
  };
  render() {
    const { routes, changeSearchBy, searchBy, loading } = this.props;
    return !loading ? (
      <View style={{ flex: 1, backgroundColor: primaryBlue }}>
        {/* <NavigationEvents onWillFocus={this.fetchRoutes} /> */}
        <View
          style={{
            display: "flex",
            position: "relative",
            flexDirection: "row",
            backgroundColor: "#FFF8F0"
          }}
        >
          <Input
            placeholder="Search city here.."
            placeholderTextColor="#333"
            minLength={2}
            autoFocus={false}
            onSubmitEditing={this.fetchRoutes}
            containerStlye={{
              width: "100%",
              // borderRadius: 25,
              borderWidth: 0,
              marginTop: 0,
              marginTop: 20,
              backgroundColor: "transparent",
              fontFamily: "Montserrat-Regular",
              borderColor: "transparent",
              backgroundColor: "#FFF8F0",
              padding: 0, // added
              margin: 0 //added
            }}
            inputContainerStyle={{
              // paddingTop: 20,
              // paddingRight: 13,
              // paddingLeft: 13,
              backgroundColor: "#FFF8F0",
              borderWidth: 0,
              padding: 0, // added
              margin: 0, //added
              borderColor: "transparent"
            }}
            inputStyle={{
              marginLeft: 0,
              marginRight: 0,
              // width: 200,
              color: "#5d5d5d",
              borderWidth: 0,
              backgroundColor: "#FFF8F0",
              fontSize: 18,
              paddingRight: 10,
              paddingLeft: 20,
              // borderRadius: 25,
              fontFamily: "Montserrat-Regular",
              borderColor: "transparent"
            }}
            onChangeText={val => changeSearchBy(val)}
            currentLocation={false}
          />
          <Button
            icon={
              <Icon
                name="magnify"
                style={{ fontSize: 31, color: primaryBlue }}
              />
            }
            buttonStyle={{
              backgroundColor: "transparent",
              borderLeftColor: "#999",
              borderLeftWidth: 0.5
            }}
            onPress={this.fetchRoutes}
            containerStyle={{
              position: "absolute",
              // top: 20,
              // right: 20,
              top: 0,
              right: 0,
              backgroundColor: "#FFF8F0"
              // borderRadius: 25
            }}
          />
        </View>
        {routes ? (
          <Text
            style={{
              fontFamily: "Montserrat-Light",
              fontSize: 14,
              paddingTop: 10,
              paddingBottom: 10,
              width: "100%",
              textAlign: "center",
              color: "#fff",
              borderBottomColor: "#eee",
              borderBottomWidth: 1
            }}
          >
            {" "}
            Total: {routes.length} results{" "}
          </Text>
        ) : (
          <Text
            style={{
              fontFamily: "Montserrat-Light",
              fontSize: 14,
              paddingTop: 10,
              paddingBottom: 10,
              width: "100%",
              textAlign: "center",
              color: "#fff",
              borderBottomColor: "#eee",
              borderBottomWidth: 1
            }}
          >
            0 results
          </Text>
        )}
        {routes ? (
          <FlatList
            data={routes}
            renderItem={({ item }) => (
              <ListItem
                title={item.name}
                containerStyle={{
                  backgroundColor: "transparent",
                  borderBottomColor: "#fff",
                  borderBottomWidth: 1
                }}
                rightContentContainerStyle={{
                  display: "flex",
                  height: "100%",
                  borderLeftColor: "#eee",
                  paddingTop: 3,
                  borderLeftWidth: 1,
                  marginLeft: 10,
                  paddingLeft: 10,
                  justifyContent: "flex-start"
                }}
                leftContentContainerStyle={{
                  paddingRight: 10
                }}
                titleStyle={{
                  fontFamily: "Montserrat-Light",
                  fontSize: 20,
                  color: "#fff",
                  marginBottom: 10
                }}
                rightTitle={
                  <View style={{ alignSelf: "flex-end" }}>
                    <AirbnbRating
                      showRating={false}
                      defaultRating={item.rating.total}
                      size={16}
                    />
                  </View>
                }
                rightSubtitle={
                  <View style={{ display: "flex" }}>
                    <View
                      style={{
                        marginBottom: 10,
                        marginTop: 10,
                        display: "flex",
                        flexDirection: "row",
                        justifyContent: "flex-end",
                        alignItems: "center"
                      }}
                    >
                      <Text
                        style={{
                          fontSize: 16,
                          color: "#fff",
                          fontFamily: "Montserrat-SemiBold"
                        }}
                      >
                        {item.duration}
                      </Text>
                      <AwesomeIcon
                        name="walking"
                        style={{
                          fontSize: 14,
                          paddingLeft: 16,
                          color: "#fff"
                        }}
                      />
                    </View>
                    <View
                      style={{
                        marginBottom: 10,
                        display: "flex",
                        justifyContent: "flex-end",
                        flexDirection: "row",
                        alignItems: "center"
                      }}
                    >
                      <Text
                        style={{
                          fontSize: 16,
                          color: "#fff",
                          fontFamily: "Montserrat-SemiBold"
                        }}
                      >
                        {item.distance}
                      </Text>
                      <AwesomeIcon
                        name="ruler"
                        style={{
                          fontSize: 16,
                          paddingLeft: 10,
                          color: "#fff"
                        }}
                      />
                    </View>
                    <View
                      style={{
                        marginBottom: 10,
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "center"
                      }}
                    >
                      <Button
                        title="See route"
                        titleStyle={{
                          fontFamily: "Montserrat-SemiBold",
                          fontSize: 18,
                          padding: 0,
                          color: stridentRed
                        }}
                        buttonStyle={{
                          backgroundColor: "transparent",
                          padding: 0,
                          paddingTop: 8,
                          paddingBottom: 10
                        }}
                        onPress={() =>
                          this.props.navigation.navigate("RouteView", { item })
                        }
                        containerStyle={{
                          backgroundColor: "transparent",
                          padding: 0,
                          marginTop: 5,
                          width: "90%",
                          borderTopWidth: 1,
                          borderTopColor: "#fff",
                          marginRight: 8
                        }}
                      />
                    </View>
                  </View>
                }
                subtitle={
                  <View style={{ display: "flex" }}>
                    <View
                      style={{
                        marginBottom: 10,
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "center"
                      }}
                    >
                      <AwesomeIcon
                        name="map-marker-alt"
                        style={{
                          fontSize: 16,
                          paddingRight: 10,
                          color: stridentRed
                        }}
                      />
                      <Text
                        style={{
                          fontSize: 16,
                          color: "#fff",
                          fontFamily: "Montserrat-Regular"
                        }}
                      >
                        {item.city}
                      </Text>
                    </View>
                    <View
                      style={{
                        marginBottom: 10,
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "center"
                      }}
                    >
                      <AwesomeIcon
                        name="info-circle"
                        style={{
                          fontSize: 16,
                          paddingRight: 8,
                          color: "#fff"
                        }}
                      />
                      <Text
                        numberOfLines={2}
                        style={{
                          flex: 1,
                          flexWrap: "wrap",
                          fontSize: 16,
                          color: "#fff",
                          fontFamily: "Montserrat-Regular"
                        }}
                      >
                        {item.description}
                      </Text>
                    </View>
                    <View
                      style={{
                        marginBottom: 10,
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "center"
                      }}
                    >
                      <AwesomeIcon
                        name="user-alt"
                        style={{
                          fontSize: 16,
                          paddingRight: 8,
                          color: "#fff"
                        }}
                      />
                      <Text
                        style={{
                          fontSize: 16,
                          color: stridentYellow,
                          fontFamily: "Montserrat-SemiBold"
                        }}
                      >
                        by {item.user.username}
                      </Text>
                    </View>
                  </View>
                }
                key={item.key}
              >
                {item.key}
              </ListItem>
            )}
          />
        ) : (
          <Text
            style={{
              width: "100%",
              fontSize: 16,
              marginTop: 50,
              fontFamily: "Montserrat-SemiBold",
              textAlign: "center",
              color: primaryRed
            }}
          >
            {" "}
            No routes found. Be the first to add it!{" "}
          </Text>
        )}
      </View>
    ) : (
      <LoadingScreen />
    );
  }
}

export default connect(
  state => ({
    searchBy: state.routes.searchBy,
    routes: state.routes.routes,
    loading: state.routes.loading
  }),
  { fetchRoutes, changeSearchBy }
)(RoutesScreen);
