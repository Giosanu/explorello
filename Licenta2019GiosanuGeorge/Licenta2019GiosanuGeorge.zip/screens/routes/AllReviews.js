import React from "react";
import { View, StyleSheet, Text, FlatList, Image } from "react-native";
import { Button, AirbnbRating, ListItem } from "react-native-elements";
import {
  primaryBlue,
  primaryRed,
  primaryYellow,
  white,
  stridentRed,
  stridentYellow
} from "../../constants/Colors";
import { connect } from "react-redux";
import Icon from "react-native-vector-icons/MaterialCommunityIcons";
import AwesomeIcon from "react-native-vector-icons/FontAwesome5";
import { fetchReviews } from "./RoutesActions";
import { navigationOptions } from "../../constants/headerStyles";

class AllReviews extends React.Component {
  static navigationOptions = {
    ...navigationOptions,
    ...{
      headerLeft: props => {
        goBack = props.onPress;
        return (
          <Button
            containerStyle={{ backgroundColor: "transparent" }}
            buttonStyle={{ backgroundColor: "transparent" }}
            title=""
            onPress={props.onPress}
            icon={
              <Icon name="arrow-left" style={{ color: "#fff", fontSize: 24 }} />
            }
          />
        );
      },
      headerRight: <View />
    }
  };
  componentDidMount() {
    this.props.fetchReviews(this.props.navigation.state.params.key);
  }
  render() {
    const { reviews, user } = this.props;
    return (
      <View style={styles.container}>
        <Text
          style={{
            width: "100%",
            fontSize: 24,
            paddingTop: 10,
            paddingBottom: 10,
            textAlign: "center",
            backgroundColor: stridentYellow,
            color: primaryBlue,
            borderBottomColor: white,
            borderBottomWidth: 0.5,
            fontFamily: "Montserrat-SemiBold"
          }}
        >
          {this.props.navigation.state.params.name}{"\n"}
          <Text style={{fontSize: 18}}>(reviews)</Text>
        </Text>
        <FlatList
          data={reviews}
          renderItem={({ item }) => (
            <ListItem
              title={
                <View
                  style={{
                    display: "flex",
                    alignItems: "center",
                    width: "100%",
                    flexDirection: "row",
                    justifyContent: "space-between"
                  }}
                >
                  <View style={{display: 'flex', flexDirection:'row', alignItems: 'center'}}>
                    <Image
                      source={require('../../assets/images/ava.png')}
                      style={{
                        width: 27,
                        height: 24,
                        marginRight: 10,
                        paddingBottom: 9
                      }}
                    />
                    <Text
                      style={{
                        fontFamily: "Montserrat-SemiBold",
                        fontSize: 20,
                        color: "#fff",
                        paddingTop: 5,
                        marginBottom: 10
                      }}
                    >
                      {user.uid === item.user.uid ? "You" : item.user.username}
                    </Text>
                  </View>
                  <AirbnbRating
                    showRating={false}
                    defaultRating={item.rating}
                    size={16}
                  />
                </View>
              }
              containerStyle={{
                backgroundColor: "#14445A",
                borderBottomColor: "#fff",
                borderBottomWidth: 0.5
              }}
              subtitle={
                <View style={{ display: "flex" }}>
                  <View
                    style={{
                      marginBottom: 10,
                      display: "flex",
                      width: "100%",
                      flexDirection: "column",
                      alignItems: "center"
                    }}
                  >
                    <Text
                      style={{
                        flex: 1,
                        flexWrap: "wrap",
                        fontSize: 16,
                        color: "#fff",
                        fontFamily: "Montserrat-Regular"
                      }}
                    >
                      {item.description}
                    </Text>
                    <Text
                      style={{
                        width: "100%",
                        fontSize: 14,
                        textAlign: "right",
                        color: "#eee",
                        paddingTop: 10,
                        fontFamily: "Montserrat-SemiBold"
                      }}
                    >
                      {item.created_at}
                    </Text>
                  </View>
                </View>
              }
              key={item.key}
            >
              {item.key}
            </ListItem>
          )}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: primaryBlue
  }
});

export default connect(
  state => ({
    reviews: state.routes.reviews,
    user: state.login.currentUser
  }),
  { fetchReviews }
)(AllReviews);
