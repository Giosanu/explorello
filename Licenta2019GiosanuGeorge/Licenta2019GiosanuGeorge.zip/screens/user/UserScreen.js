import React from "react";
import {
  View,
  StyleSheet,
  Text,
  Image,
  TextInput,
  ImageBackground
} from "react-native";
import { Button } from "react-native-elements";
import { connect } from "react-redux";
import { navigationOptions } from "../../constants/headerStyles";
import Icon from "react-native-vector-icons/MaterialCommunityIcons";
import AwesomeIcon from "react-native-vector-icons/FontAwesome5";
import {
  stridentRed,
  primaryBlue,
  stridentYellow,
  primaryYellow,
  primaryRed
} from "../../constants/Colors";
import { clearData } from "./UserActions";
import { fetchCompletedRoutes, fetchMyEvents } from "../routes/RoutesActions";

class UserScreen extends React.Component {
  static navigationOptions = {
    headerStyle: {
      height: 0
    },
    headerTitle: null
  };
  componentDidMount() {
    const { currentUser, fetchCompletedRoutes, fetchMyEvents } = this.props;
    fetchCompletedRoutes(currentUser.uid);
    fetchMyEvents(currentUser.uid);
  }
  render() {
    const { clearData, navigation, currentUser, completed } = this.props;
    let dist = 0;
    let h = 0;
    let min = 0;
    completed.map(c => {
      dist += parseInt(c.distance.split(' ')[0])
      h += parseInt(c.duration.split('h')[0])
      min += parseInt(c.duration.split(' ')[1].split('min')[0])
      h += Math.floor(min / 60)
      min = min % 60
    });
    return (
      <View style={styles.container}>
        <View
          style={{
            width: "100%",
            height: "100%",
            position: "relative",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "space-around"
          }}
        >
          <View
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              width: "100%",
              height: "20%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              borderBottomColor: "#eee"
            }}
          >
            <Image
              source={require("../../assets/images/cover.png")}
              style={{
                width: "100%",
                height: "100%",
                borderColor: primaryBlue
              }}
            />
          </View>
          <View
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              borderBottomColor: "#fff",
              borderBottomWidth: 2
            }}
          >
            <View
              style={{
                borderRadius: 200,
                backgroundColor: stridentYellow,
                display: "flex",
                padding: 25,
                borderWidth: 3,
                borderColor: "#eee",
                marginBottom: 10,
                alignItems: "center",
                justifyContent: "center"
              }}
            >
              <Image
                source={require("../../assets/images/ava.png")}
                style={{
                  width: 100,
                  height: 85,
                  borderColor: primaryBlue
                }}
              />
            </View>
            <Text
              style={{
                width: "100%",
                textAlign: "center",
                fontSize: 28,
                fontFamily: "Montserrat-Light",
                color: "#fff"
              }}
            >
              {currentUser.username}
            </Text>
            <View
              style={{
                display: "flex",
                width: "100%",
                flexDirection: "row",
                paddingTop: 15,
                paddingLeft: 10,
                paddingBottom: 30,
                alignItems: "center",
                justifyContent: "space-around"
              }}
            >
              <Text
                style={{
                  textAlign: "center",
                  fontSize: 18,
                  fontFamily: "Montserrat-Regular",
                  color: "#fff"
                }}
              >
                <AwesomeIcon
                  style={{ fontSize: 20, paddingRight: 10, color: stridentRed }}
                  name="ruler"
                />{" "}
                {dist} km
              </Text>
              <Text
                style={{
                  textAlign: "center",
                  fontSize: 18,
                  fontFamily: "Montserrat-Regular",
                  color: "#fff"
                }}
              >
                <AwesomeIcon
                  style={{ fontSize: 20, paddingRight: 10, color: "#B6174B" }}
                  name="football-ball"
                />{" "}
                {this.props.myEvents.length} events
              </Text>
              <Text
                style={{
                  textAlign: "center",
                  fontSize: 18,
                  fontFamily: "Montserrat-Regular",
                  color: "#fff"
                }}
              >
                <AwesomeIcon
                  style={{ fontSize: 20, paddingRight: 10, color: "#F9BB46" }}
                  name="walking"
                />{" "}
                {h}h {min}min
              </Text>
            </View>
          </View>
          <View
            style={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-between",
              alignContent: "center"
            }}
          >
            <View
              style={{
                display: "flex",
                flexDirection: "row",
                justifyContent: "space-between",
                alignContent: "center",
                marginBottom: 30
              }}
            >
              <Button
                buttonStyle={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  backgroundColor: "transparent"
                }}
                title="Map history"
                iconContainerStyle={{ width: "100%" }}
                icon={
                  <AwesomeIcon
                    style={{ fontSize: 24, color: stridentRed }}
                    name="map-marked"
                  />
                }
                titleStyle={{
                  fontSize: 18,
                  color: primaryBlue,
                  fontFamily: "Montserrat-Bold"
                }}
                onPress={() => this.props.navigation.navigate("MapHistory")}
                containerStyle={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  width: "45%",
                  backgroundColor: "#FFF8F0", //"rgba(0,48,73,0.9)",
                  paddingRight: 10,
                  borderRadius: 20,
                  paddingLeft: 10
                }}
              />
              <Button
                buttonStyle={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  backgroundColor: "transparent"
                }}
                title="My routes"
                iconContainerStyle={{ width: "100%" }}
                icon={
                  <Image
                    source={require("../../assets/images/myRoutes.png")}
                    style={{ width: 75, height: 25 }}
                  />
                }
                titleStyle={{
                  fontSize: 18,
                  color: primaryBlue,
                  fontFamily: "Montserrat-Bold"
                }}
                containerStyle={{
                  display: "flex",
                  alignItems: "center",
                  borderRadius: 20,
                  justifyContent: "center",
                  width: "45%",
                  backgroundColor: "#FFF8F0", //"rgba(0,48,73,0.9)",
                  paddingRight: 10,
                  paddingLeft: 10
                }}
                onPress={() => {
                  navigation.navigate("MyRoutes");
                }}
              />
            </View>
            <View
              style={{
                display: "flex",
                flexDirection: "row",
                justifyContent: "space-between",
                alignContent: "center"
              }}
            >
              <Button
                buttonStyle={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  backgroundColor: "transparent"
                }}
                title="Settings"
                iconContainerStyle={{ width: "100%" }}
                icon={
                  <AwesomeIcon
                    style={{ fontSize: 24, color: primaryRed }}
                    name="cog"
                  />
                }
                titleStyle={{
                  fontSize: 18,
                  color: primaryBlue,
                  fontFamily: "Montserrat-Bold"
                }}
                onPress={this.getCurrentPosition}
                containerStyle={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  width: "45%",
                  backgroundColor: "#FFF8F0", //"rgba(0,48,73,0.9)",
                  paddingRight: 10,
                  borderRadius: 20,
                  paddingLeft: 10
                }}
                onPress={() => {
                  clearData();
                  navigation.navigate("Login");
                }}
              />
              <Button
                buttonStyle={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  backgroundColor: "transparent"
                }}
                title="Travel history"
                iconContainerStyle={{ width: "100%" }}
                icon={
                  <AwesomeIcon
                    style={{ fontSize: 24, color: stridentYellow }}
                    name="history"
                  />
                }
                titleStyle={{
                  fontSize: 18,
                  color: primaryBlue,
                  fontFamily: "Montserrat-Bold"
                }}
                containerStyle={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  width: "45%",
                  backgroundColor: "#FFF8F0", //"rgba(0,48,73,0.9)",
                  paddingRight: 10,
                  borderRadius: 20,
                  paddingLeft: 10
                }}
                onPress={() => {
                  navigation.navigate("TravelHistory");
                }}
              />
            </View>
          </View>
          <View
            style={{
              height: 2,
              backgroundColor: "#fff",
              width: "100%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center"
            }}
          >
            <View
              style={{
                height: 40,
                width: 40,
                backgroundColor: "#fff",
                borderRadius: 20,
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center"
              }}
              onPress={() => {
                clearData();
                navigation.navigate("Login");
              }}
            >
              <Button
                buttonStyle={{
                  backgroundColor: "transparent",
                  padding: 0
                }}
                containerStyle={{
                  backgroundColor: "#fff",
                  borderRadius: 20
                }}
                onPress={() => {
                  clearData();
                  navigation.navigate("Login");
                }}
                icon={
                  <AwesomeIcon
                    style={{
                      fontSize: 24,
                      color: primaryBlue
                    }}
                    name="sign-out-alt"
                  />
                }
              />
            </View>
          </View>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: primaryBlue
  }
});

export default connect(
  state => ({
    currentUser: state.login.currentUser,
    completed: state.routes.completed,
    myEvents: state.routes.myEvents
  }),
  { clearData, fetchCompletedRoutes, fetchMyEvents }
)(UserScreen);
