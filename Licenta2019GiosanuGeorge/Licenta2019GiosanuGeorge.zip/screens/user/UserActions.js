export const CLEAR_DATA = 'CLEAR_DATA'

export const clearData = () => ({
    type: CLEAR_DATA
})