import { createAppContainer, createStackNavigator } from "react-navigation";
import AddRouteScreen from "./AddRouteScreen";
import AddRouteManually from "./AddRouteManually";
import EndAddRoute from "./EndAddRouteScreen";
import AddRouteDynamically from "./AddRouteDynamically";

export default createAppContainer(
  createStackNavigator({
    AddRouteLanding: { screen: AddRouteScreen },
    EndAddRoute: { screen: EndAddRoute },
    AddRouteDynamically: { screen: AddRouteDynamically},
    AddRouteManually: { screen: AddRouteManually }
  })
);
