import React from "react";
import {
  View,
  StyleSheet,
  Text,
  ImageBackground,
  TextInput
} from "react-native";
import Modal from "react-native-modal";
import { Image, Button } from "react-native-elements";
import MapViewDirections from "react-native-maps-directions";
import {
  primaryBlue,
  primaryRed,
  primaryYellow,
  white,
  stridentRed,
  stridentYellow
} from "../../constants/Colors";
import { storeRoute, setCurrentPosition } from "./AddRouteActions";
import Geolocation from "react-native-geolocation-service";
import MapView, { Marker, PROVIDER_GOOGLE } from "react-native-maps";
import { GooglePlacesAutocomplete } from "react-native-google-places-autocomplete";
import { mapStyle } from "../../constants/Styles";
import { connect } from "react-redux";
import TabBarIcon from "../../components/TabBarIcon";
import Icon from "react-native-vector-icons/MaterialCommunityIcons";
import { GoogleApiKey } from "../../config/keys";
import { navigationOptions } from "../../constants/headerStyles";
import { informativeToast } from "../../constants/Functions";

class AddRouteDynamically extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      location: null,
      showEndModal: false,
      cityConfirmed: false,
      formattedAddress: [],
      startedRoute: false,
      position: {},
      endedRoute: false,
      canAddWaypoint: false,
      markers: [],
      showDescriptionModal: false,
      description: "",
      showMarkerOptions: false,
      currentMarker: 0,
      route: []
    };
  }
  updatePosition = () => {
    Geolocation.getCurrentPosition(
      position => {
        let pos = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          latitudeDelta: 0.09,
          longitudeDelta: 0.04
        };
        this.setState({
          position: pos,
          location: pos,
          canAddWaypoint: true
        });
      },
      error => {
        // See error code charts below.
        console.log(error.code, error.message);
        this.setState({ loading: false });
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
    );
  };
  componentDidMount() {
    const { state } = this.props.navigation;
    Geolocation.watchPosition(
      position => {
        let pos = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          latitudeDelta: 0.09,
          longitudeDelta: 0.04
        };
        this.setState({
          position: pos,
          canAddWaypoint: true
        });
        fetch(
          "https://maps.googleapis.com/maps/api/geocode/json?latlng=" +
            position.coords.latitude +
            "," +
            position.coords.longitude +
            "&key=" +
            GoogleApiKey +
            "&result_type=locality"
        )
          .then(response => response.json())
          .then(responseJson => {
            let formattedAddress = [];
            if (responseJson.plus_code.compound_code) {
              let result = responseJson.plus_code.compound_code
                .replace(
                  responseJson.plus_code.compound_code.split(" ")[0] + " ",
                  ""
                )
                .split(", ");
              if (responseJson.results.length > 0) {
                formattedAddress = responseJson.results[0].formatted_address
                  .replace(/[0-9]/g, "")
                  .split(",");
              } else {
                formattedAddress = [result[0], result[result.length - 1]];
              }
            } else {
              formattedAddress = ["Narnia..", "Sorry, we couldn't find you"];
            }
            this.setState({formattedAddress})
          })
          .catch(err => console.log(err));
      },
      error => {
        // See error code charts below.
        console.log(error.code, error.message);
        this.setState({ loading: false });
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
    );
  }
  updateRoute = () => {
    let newMarkers = [...this.state.markers];
    newMarkers.push(this.state.position);
    this.setState({
      markers: newMarkers,
      startedRoute: true,
      canAddWaypoint: false
    });
  };
  static navigationOptions = {
    ...navigationOptions,
    ...{
      headerLeft: props => {
        return (
          <Button
            containerStyle={{ backgroundColor: "transparent" }}
            buttonStyle={{ backgroundColor: "transparent" }}
            title=""
            onPress={props.onPress}
            icon={
              <Icon name="arrow-left" style={{ color: "#fff", fontSize: 24 }} />
            }
          />
        );
      },
      headerRight: <View />
    }
  };
  updateDescription = () => {
    const { currentMarker, markers, description } = this.state;
    let newMarkers = [];
    markers.map((mark, index) => {
      if (index !== currentMarker) {
        newMarkers.push(mark);
      } else {
        newMarkers.push({ ...mark, ...{ description } });
      }
    });

    this.setState({
      showDescriptionModal: false,
      description: "",
      markers: newMarkers
    });
  };
  deleteWaypoint = () => {
    const { currentMarker, markers } = this.state;
    let newMarkers = [];
    markers.map((mark, index) => {
      if (index !== currentMarker) {
        newMarkers.push(mark);
      } else {
        // nothing
      }
    });

    this.setState({
      showDescriptionModal: false,
      canAddWaypoint: true,
      showMarkerOptions: false,
      markers: newMarkers
    });
  };
  render() {
    const { location, markers } = this.state;
    console.log("route: ", this.props.route);
    return (
      <View style={styles.container}>
        <Modal isVisible={this.state.showEndModal}>
          <View
            style={{
              flex: 1,
              display: "flex",
              alignItems: "center",
              justifyContent: "center"
            }}
          >
            <Text
              style={{
                color: "#fff",
                fontSize: 20,
                textAlign: "center",
                fontFamily: "Montserrat-Regular"
              }}
            >
              Continue to the next step?
            </Text>
            <View
              style={{
                display: "flex",
                width: "100%",
                flexDirection: "row",
                paddingTop: 40,
                justifyContent: "center",
                alignItems: "center"
              }}
            >
              <Button
                buttonStyle={{
                  backgroundColor: "transparent"
                }}
                containerStyle={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  width: 100,
                  marginRight: 40,
                  borderRadius: 25,
                  backgroundColor: "#eee",
                  height: 40
                }}
                title="No"
                titleStyle={{
                  fontSize: 15,
                  color: primaryBlue,
                  fontFamily: "Montserrat-Bold"
                }}
                onPress={() =>
                  this.setState({ showEndModal: false, endedRoute: true })
                }
              />
              <Button
                buttonStyle={{
                  backgroundColor: "transparent"
                }}
                containerStyle={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  width: 100,
                  borderRadius: 25,
                  backgroundColor: "#ff4d00",
                  height: 40
                }}
                title="Yes"
                titleStyle={{
                  fontSize: 15,
                  color: "#fff",
                  fontFamily: "Montserrat-Bold"
                }}
                onPress={() =>
                  this.setState(
                    { showEndModal: false, endedRoute: true },
                    () => {
                      setTimeout(
                        () =>
                          this.props.navigation.navigate(
                            "EndAddRoute",
                            this.state.markers
                          ),
                        1000
                      );
                      this.props.storeRoute({
                        markers: this.state.markers,
                        formattedAddress: this.state.formattedAddress
                      });
                    }
                  )
                }
              />
            </View>
          </View>
        </Modal>
        <Modal isVisible={this.state.showDescriptionModal}>
          <View
            style={{
              flex: 1,
              display: "flex",
              alignItems: "center",
              justifyContent: "center"
            }}
          >
            <Text
              style={{
                width: "80%",
                textAlign: "center",
                fontSize: 18,
                backgroundColor: "#14445A",
                paddingTop: 5,
                paddingBottom: 5,
                borderColor: primaryYellow,
                borderWidth: 1,
                fontFamily: "Montserrat-Bold",
                color: primaryYellow
              }}
            >
              Add a description below
            </Text>
            <TextInput
              style={{
                backgroundColor: primaryYellow,
                width: "80%",
                color: primaryBlue,
                fontSize: 16,
                fontFamily: "Montserrat-Regular",
                paddingTop: 5,
                paddingRight: 40,
                paddingLeft: 40,
                borderBottomLeftRadius: 15,
                borderBottomRightRadius: 15,
                height: 100
              }}
              secureTextEntry={
                this.state.description.length <= 0 &&
                this.state.descriptionStatus != "onFocus"
                  ? true
                  : false
              }
              multiline
              onChangeText={description => this.setState({ description })}
              placeholderTextColor={"#aaa"}
              placeholder={
                "Ex: This is a key waypoint, you need to grab a coffee from here!"
              }
              numberOfLines={3}
            />
            <View
              style={{
                display: "flex",
                width: "100%",
                flexDirection: "row",
                paddingTop: 40,
                justifyContent: "center",
                alignItems: "center"
              }}
            >
              <Button
                buttonStyle={{
                  backgroundColor: "transparent"
                }}
                containerStyle={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  width: 100,
                  marginRight: 40,
                  borderRadius: 25,
                  backgroundColor: "#eee",
                  height: 40
                }}
                title="No"
                titleStyle={{
                  fontSize: 15,
                  color: primaryBlue,
                  fontFamily: "Montserrat-Bold"
                }}
                onPress={() =>
                  this.setState({ showEndModal: false, endedRoute: true })
                }
              />
              <Button
                buttonStyle={{
                  backgroundColor: "transparent"
                }}
                containerStyle={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  width: 100,
                  borderRadius: 25,
                  backgroundColor: "#ff4d00",
                  height: 40
                }}
                title="Confirm"
                titleStyle={{
                  fontSize: 15,
                  color: "#fff",
                  fontFamily: "Montserrat-Bold"
                }}
                onPress={this.updateDescription}
              />
            </View>
          </View>
        </Modal>
        <MapView
          provider={PROVIDER_GOOGLE}
          showsMyLocationButton={false}
          region={location || this.props.currentPosition}
          style={{ flex: 1 }}
          onPress={() => this.setState({ showMarkerOptions: false })}
          onRegionChangeComplete={location => this.setState({ location })}
          customMapStyle={mapStyle}
          showsUserLocation
        >
          {this.props.currentPosition &&
            this.state.markers.map((marker, index) => (
              <Marker
                coordinate={marker}
                key={index}
                draggable
                tracksViewChanges={false}
                onDragEnd={e => {
                  let newMarkers = [];
                  this.state.markers.map((mark, ind) => {
                    if (index !== ind) {
                      newMarkers.push(mark);
                    } else {
                      newMarkers.push({
                        longitude: e.nativeEvent.coordinate.longitude,
                        latitude: e.nativeEvent.coordinate.latitude,
                        longitudeDelta: 0.03,
                        latitudeDelta: 0.04,
                        description: mark.description || ""
                      });
                    }
                  });

                  this.setState({ markers: newMarkers });
                }}
                onPress={() =>
                  this.setState({
                    currentMarker: index,
                    showMarkerOptions: true
                  })
                }
                tracksViewChanges={false}
                description={marker.description || ""}
                title={`Point ${index + 1}`}
                pinColor={
                  (index === 0 && stridentRed) ||
                  (index !== this.state.markers.length - 1 && primaryBlue) ||
                  primaryYellow
                }
              />
            ))}

          {markers.length > 0 && (
            <MapViewDirections
              strokeWidth={6}
              strokeColor={primaryRed}
              mode="WALKING"
              onError={error => errorToast(error)}
              origin={markers[0]}
              waypoints={markers.map(
                (m, i) => (i !== 0 || i !== markers.length) && m
              )}
              destination={markers[markers.length - 1]}
              apikey={GoogleApiKey}
            />
          )}
        </MapView>
        <View
          style={{
            position: "absolute",
            top: 0,
            width: "100%",
            height: "100%",
            flex: 1,
            display: "flex",
            justifyContent: "space-between",
            left: 0
          }}
        >
          {this.props.currentPosition && !this.state.startedRoute && (
            <View
              style={{
                display: "flex",
                height: "100%",
                paddingBottom: 20,
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "space-between"
              }}
            >
              <View
                style={{
                  width: "100%",
                  display: "flex",
                  alignItems: "flex-end"
                }}
              >
                <Button
                  buttonStyle={{
                    backgroundColor: "transparent",
                    width: "100%"
                  }}
                  icon={
                    <Icon
                      name="crosshairs-gps"
                      style={{ color: "#000", fontSize: 24 }}
                    />
                  }
                  onPress={this.updatePosition}
                  containerStyle={{
                    display: "flex",
                    alignItems: "flex-end",
                    justifyContent: "center",
                    width: 45,
                    height: 45,
                    borderRadius: 45,
                    marginTop: 20,
                    marginRight: 20,
                    borderWidth: 1,
                    borderColor: "#000",
                    backgroundColor: stridentYellow
                  }}
                />
              </View>
              <Button
                buttonStyle={{
                  backgroundColor: "transparent",
                  width: "100%"
                }}
                title="Start route"
                titleStyle={{
                  fontSize: 15,
                  color: "#fff",
                  fontFamily: "Montserrat-Bold"
                }}
                onPress={() => {
                  this.updateRoute();
                }}
                containerStyle={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  width: "80%",
                  borderRadius: 15,
                  backgroundColor: "#ff4d00",
                  height: 40
                }}
              />
            </View>
          )}
          {!this.state.showMarkerOptions ? (
            <View
              style={{ width: "100%", display: "flex", alignItems: "flex-end" }}
            >
              <Button
                buttonStyle={{
                  backgroundColor: "transparent",
                  width: "100%"
                }}
                icon={
                  <Icon
                    name="crosshairs-gps"
                    style={{ color: "#000", fontSize: 24 }}
                  />
                }
                onPress={this.updatePosition}
                containerStyle={{
                  display: "flex",
                  alignItems: "flex-end",
                  justifyContent: "center",
                  width: 45,
                  height: 45,
                  borderRadius: 45,
                  marginTop: 20,
                  marginRight: 20,
                  borderWidth: 1,
                  borderColor: "#000",
                  backgroundColor: stridentYellow
                }}
              />
            </View>
          ) : (
            <View
              style={{
                paddingTop: 20,
                width: "100%",
                height: "50%",
                positin: "absolute",
                display: "flex",
                alignItems: "flex-start",
                flexDirection: "row",
                justifyContent: "space-around"
              }}
            >
              <Button
                buttonStyle={{
                  backgroundColor: "transparent",
                  width: "100%",
                  borderRadius: 25
                }}
                containerStyle={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  width: "45%",
                  borderRadius: 25,
                  backgroundColor: "#fff",
                  height: 40
                }}
                title="Add description"
                titleStyle={{
                  fontSize: 15,
                  color: primaryBlue,
                  fontFamily: "Montserrat-Bold"
                }}
                onPress={() => this.setState({ showDescriptionModal: true })}
              />
              <Button
                buttonStyle={{
                  backgroundColor: "transparent",
                  width: "100%",
                  borderRadius: 25
                }}
                title="Delete waypoint"
                titleStyle={{
                  fontSize: 15,
                  color: "#fff",
                  fontFamily: "Montserrat-Bold"
                }}
                onPress={this.deleteWaypoint}
                containerStyle={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  width: "45%",
                  borderRadius: 25,
                  backgroundColor: stridentRed,
                  height: 40
                }}
              />
            </View>
          )}
          {this.props.currentPosition && this.state.startedRoute && (
            <View
              style={{
                paddingBottom: 20,
                width: "100%",
                height: "50%",
                display: "flex",
                alignItems: "flex-end",
                flexDirection: "row",
                justifyContent: "space-around"
              }}
            >
              <Button
                buttonStyle={{
                  backgroundColor: "transparent",
                  width: "100%",
                  borderRadius: 25
                }}
                containerStyle={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  width: "45%",
                  borderRadius: 25,
                  backgroundColor: primaryBlue,
                  height: 40
                }}
                title="Add waypoint"
                titleStyle={{
                  fontSize: 15,
                  color: "#f9b332",
                  fontFamily: "Montserrat-Bold"
                }}
                disabled={!this.state.canAddWaypoint}
                disabledStyle={{
                  backgroundColor: "#eee"
                }}
                onPress={() => {
                  if (this.state.markers.length < 2) {
                    informativeToast(
                      "Hint: the more waypoints you add, the more accurate the route will be!"
                    );
                  }
                  this.updateRoute();
                  // this.setState({
                  //   markers: [...this.state.markers, this.state.location]
                  // });
                }}
              />
              <Button
                buttonStyle={{
                  backgroundColor: "transparent",
                  width: "100%",
                  borderRadius: 25
                }}
                disabled={this.state.markers.length < 2}
                disabledStyle={{
                  backgroundColor: "#eee"
                }}
                title="End route"
                titleStyle={{
                  fontSize: 15,
                  color: primaryBlue,
                  fontFamily: "Montserrat-Bold"
                }}
                onPress={() => {
                  this.setState({ showEndModal: true });
                }}
                containerStyle={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  width: "45%",
                  borderRadius: 25,
                  backgroundColor: "#f9b332",
                  height: 40
                }}
              />
            </View>
          )}
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff"
  }
});

export default connect(
  state => ({
    currentPosition: state.addRoute.currentPosition,
    route: state.addRoute.route
  }),
  { storeRoute, setCurrentPosition }
)(AddRouteDynamically);
