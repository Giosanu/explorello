import { createStore, applyMiddleware, combineReducers } from "redux";
import LoginReducer from '../screens/login/LoginReducer'
import { persistStore, persistReducer } from 'redux-persist'
import storage from 'redux-persist/lib/storage' 
import thunk from "redux-thunk";
import AddRouteReducer from '../screens/add-route/AddRouteReducer';
import RoutesReducer from "../screens/routes/RoutesReducer";

const loginConfig = {
  key: 'login',
  storage,
}
const persistedLogin = persistReducer(loginConfig, LoginReducer)

const addRouteConfig = {
  key: 'addRoute',
  storage,
}
const persistedAddRoute = persistReducer(addRouteConfig, AddRouteReducer)

const routesConfig = {
  key: 'routes',
  storage,
}
const persistedRoutes = persistReducer(routesConfig, RoutesReducer)

let store = createStore(combineReducers({
  login: persistedLogin,
  routes: persistedRoutes,
  addRoute: persistedAddRoute
}), applyMiddleware(thunk));

export const persistor = persistStore(store)

export default store