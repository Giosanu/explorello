// Your web app's Firebase configuration
import { YellowBox } from 'react-native';

YellowBox.ignoreWarnings(['Require cycle:'], ['The prop'])
console.disableYellowBox = true;

export const firebaseConfig = {
  apiKey: "AIzaSyBPrvYPz_s5GP5KgV9cwEhj3XqoBDV7_vk",
  authDomain: "explorellow.firebaseapp.com",
  databaseURL: "https://explorellow.firebaseio.com",
  projectId: "explorellow",
  storageBucket: "explorellow.appspot.com",
  messagingSenderId: "106475628676",
  appId: "1:106475628676:web:349962fefce617e6"
}
