import React from 'react';
import { Platform } from 'react-native';
import { createStackNavigator, createAppContainer, createBottomTabNavigator } from 'react-navigation';

import TabBarIcon from '../components/TabBarIcon';
import DashboardScreen from '../screens/dashboard/DashboardScreen';
import RoutesNavigator from '../screens/routes/RoutesNavigator';
import SettingsScreen from '../screens/SettingsScreen';
import AddRouteNavigator from '../screens/add-route/AddRouteNavigator';
import UserScreen from '../screens/user/UserScreen';

const HomeStack = createStackNavigator({
  Dashboard: DashboardScreen
});

HomeStack.navigationOptions = {
  tabBarIcon: ({ focused }) => (
    <TabBarIcon
      focused={focused}
      name='home'
    />
  ),
};

RoutesNavigator.navigationOptions = {
  tabBarIcon: ({ focused }) => (
    <TabBarIcon
      focused={focused}
      name='magnify'
    />
  ),
};


AddRouteNavigator.navigationOptions = {
  tabBarIcon: ({ focused }) => (
    <TabBarIcon
      focused={focused}
      name='map-marker-plus'
    />
  ),
}
const UserStack = createStackNavigator({
  UserScreen: UserScreen,
});

UserStack.navigationOptions = {
  tabBarIcon: ({ focused }) => (
    <TabBarIcon
      focused={focused}
      name='account'
    />
  ),
}

export default createAppContainer(createBottomTabNavigator({
  HomeStack,
  RoutesNavigator,
  AddRouteNavigator,
  UserStack
}, {
  tabBarOptions: {
    showLabel: false,
    inactiveBackgroundColor: 'rgba(0,48,73,0.9)',
    activeBackgroundColor: '#ff4d00'
  }
}))